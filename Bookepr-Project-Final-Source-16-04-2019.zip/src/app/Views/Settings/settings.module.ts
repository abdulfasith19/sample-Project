import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { RouterModule } from '@angular/router';

import { AllListsComponent } from './Lists/all-lists/all-lists.component';
import { ListsTermsComponent } from './Lists/lists-terms/lists-terms.component';
import { ListsPaymentComponent } from './Lists/lists-payment/lists-payment.component';
import { AttachmentListComponent } from './Lists/attachment-list/attachment-list.component';
import { RecurringTransactionsViewComponent } from './Lists/recurring-transactions-view/recurring-transactions-view.component';
import { RecurringEditComponent } from './Lists/recurring-edit/recurring-edit.component';

import { ImportDataComponent } from './Tools/Import/import-data/import-data.component';
import { ImportCustomersComponent } from './Tools/Import/import-customers/import-customers.component';

import { AccountSettingsComponent } from './Your Company/Account-Settings/account-settings/account-settings.component';

import { CustomFormListComponent } from './Your Company/Custom-form/custom-form-list/custom-form-list.component';
import { CustomFormEditComponent } from './Your Company/Custom-form/custom-form-edit/custom-form-edit.component';

import { ManageUsersComponent } from './Your Company/Manage-Users/manage-users/manage-users.component';
import { AddUsersComponent } from './Your Company/Manage-Users/add-users/add-users.component';

import { ExportDataComponent } from './Tools/export-data/export-data.component';
import { AuditComponent } from './Tools/audit/audit.component';
import { AuditViewComponent } from './Tools/audit-view/audit-view.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { OrderModule } from 'ngx-order-pipe';
import { PerfectScrollbarModule, PerfectScrollbarConfigInterface,
  PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  wheelPropagation: true
};

// nbx-bootstrap
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { CollapseModule } from 'ngx-bootstrap/collapse';

@NgModule({
  declarations: [
    AttachmentListComponent,
    RecurringTransactionsViewComponent,
    RecurringEditComponent,
    ImportDataComponent,
    ImportCustomersComponent,
    AccountSettingsComponent,
    CustomFormListComponent,
    CustomFormEditComponent,
    ManageUsersComponent,
    AddUsersComponent,
    ExportDataComponent,
    AuditComponent,
    AuditViewComponent,
    AllListsComponent,
    ListsTermsComponent,
    ListsPaymentComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    PerfectScrollbarModule,
    TabsModule.forRoot(),
    TimepickerModule.forRoot(),
    BsDatepickerModule.forRoot(),
    CollapseModule.forRoot(),
    AccordionModule.forRoot(),
    NgxPaginationModule,
    OrderModule,
    MDBBootstrapModule.forRoot(),
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ],
})
export class SettingsModule { 
 
}
