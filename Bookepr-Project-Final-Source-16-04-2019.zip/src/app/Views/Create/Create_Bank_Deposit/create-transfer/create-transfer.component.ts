import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-transfer',
  templateUrl: './create-transfer.component.html',
  styleUrls: ['./create-transfer.component.scss']
})
export class CreateTransferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
