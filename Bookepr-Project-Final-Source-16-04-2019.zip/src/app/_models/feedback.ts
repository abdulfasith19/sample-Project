export class Feedback {

	// id: number;
	// user_id: string;
	comment: string;
	// attachment_type: string;
	attachment: string;
	// created_at: string;
	// updated_at: string;
}