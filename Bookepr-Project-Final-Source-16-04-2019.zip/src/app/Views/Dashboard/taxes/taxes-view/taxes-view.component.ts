import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-taxes-view',
  templateUrl: './taxes-view.component.html',
  styleUrls: ['./taxes-view.component.scss']
})
export class TaxesViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
