import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { ViewChild } from '@angular/core';
// import { NgIf } from '../../../../../../node_modules/@angular/common';

@Component({
  selector: 'app-reconcile-checking',
  templateUrl: './reconcile-checking.component.html',
  styleUrls: ['./reconcile-checking.component.scss']
})
export class ReconcileCheckingComponent implements OnInit {

 
 // Table-Jason
collection:any;
// Table-Jason

// Sorting
order: string;
reverse: boolean = false;


sortedCollection: any[];
// Sorting

// Scrollbar
public type: string = 'component';

public disabled: boolean = false;

public config: PerfectScrollbarConfigInterface = {};

@ViewChild(PerfectScrollbarComponent) componentRef?: PerfectScrollbarComponent;
@ViewChild(PerfectScrollbarDirective) directiveRef?: PerfectScrollbarDirective;

// Scrollbar

constructor(private orderPipe: OrderPipe  ) { 
  
}

// Scrollbar
public scrollToXY(x: number, y: number): void {
  if (this.type === 'directive' && this.directiveRef) {
    this.directiveRef.scrollTo(x, y, 500);
  } else if (this.type === 'component' && this.componentRef && this.componentRef.directiveRef) {
    this.componentRef.directiveRef.scrollTo(x, y, 500);
  }
}
// Scrollbar

ngOnInit() {

  this.collection =[{
    
    "sno":'01',
    "date":'(12/02/2019)',
    "type":"Receive Payment",
    "ref_num":"205",
    "account":"Design",
    "payee":"Automobile Fuel",
    "usd_pay":"$78.20",
    "checkbox":'01'
    
  },
  {
    
    "sno":'02',
    "date":'(13/02/2019)',
    "type":"Receive Payment",
    "ref_num":"205",
    "account":"Design",
    "payee":"Automobile Fuel",
    "usd_pay":"$78.20",
    "checkbox":'02'
},
  {
    
    "sno":'03',
    "date":'(14/02/2019)',
    "type":"Receive Payment",
    "ref_num":"205",
    "account":"Design",
    "payee":"Automobile Fuel",
    "usd_pay":"$78.20",
    "checkbox":'03'
  },
    {
      
      "sno":'04',
      "date":'(15/02/2019)',
      "type":"Receive Payment",
      "ref_num":"205",
      "account":"Design",
      "payee":"Automobile Fuel",
      "usd_pay":"$78.20",
      "checkbox":'04'
    },
      {
        
        "sno":'05',
        "date":'(16/02/2019)',
        "type":"Receive Payment",
        "ref_num":"205",
        "account":"Design",
        "payee":"Automobile Fuel",
        "usd_pay":"$78.20",
        "checkbox":'06',
        
      },
      {
        
        "sno":'06',
        "date":'(17/02/2019)',
        "type":"Receive Payment",
        "ref_num":"205",
        "account":"Design",
        "payee":"Automobile Fuel",
        "usd_pay":"$78.20",
        "checkbox":'07',
        
      },
      {
        
        "sno":'07',
        "date":'(18/02/2019)',
        "type":"Receive Payment",
        "ref_num":"205",
        "account":"Design",
        "payee":"Automobile Fuel", 
        "usd_pay":"$78.20",
        "checkbox":'08',
        
    },
      {
        
        "sno":'08',
        "date":'(19/02/2019)',
        "type":"Receive Payment",
        "ref_num":"205",
        "account":"Design",
        "payee":"Automobile Fuel",
        "usd_pay":"$78.20",
        "checkbox":'09',
        
      },
        {
          
          "sno":'09',
          "date":'(20/02/2019)',
          "type":"Receive Payment",
          "ref_num":"205",
          "account":"Design",
          "payee":"Automobile Fuel",
          "usd_pay":"$78.20",
          "checkbox":'10',
          
        },
          
        {
            
            "sno":'10',
            "date":'(21/02/2019)',
            "type":"Receive Payment",
            "ref_num":"205",
            "account":"Design",
            "payee":"Automobile Fuel",
            "usd_pay":"$78.20",
            "checkbox":'11',
            
          },

]

  // console.log(this.collection)
  
}

// Sorting
setOrder(value: string) {
  console.log(value)
  if (this.order === value) {
    this.reverse = !this.reverse;
  }

  this.order = value;
}
// Sorting


// Scrollbar
public onScrollEvent(event: any): void {

}
// Scrollbar


}