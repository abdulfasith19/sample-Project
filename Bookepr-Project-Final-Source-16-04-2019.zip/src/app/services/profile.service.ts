import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders,HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { filter, finalize, map, catchError } from 'rxjs/operators';
import { UtilityService, HttpService } from '../_services';
import 'rxjs/add/operator/map';
import { resolve } from 'q';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  apiURL: string = 'http://colan.bookepr.test/api';
  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImM2ZmM3MTM4Mzc1MTM2ZGFmOWFiODBlYmRhYzczYTYzNmI1YzRlNDc2ZmE0YmY0OWQ0OTFlMGE1ZjE2NDY3NzM4MzRmMTJlZDNmNjk5ZmMxIn0.eyJhdWQiOiIxIiwianRpIjoiYzZmYzcxMzgzNzUxMzZkYWY5YWI4MGViZGFjNzNhNjM2YjVjNGU0NzZmYTRiZjQ5ZDQ5MWUwYTVmMTY0Njc3MzgzNGYxMmVkM2Y2OTlmYzEiLCJpYXQiOjE1NTQzNzc5MDIsIm5iZiI6MTU1NDM3NzkwMiwiZXhwIjoxNTg2MDAwMzAxLCJzdWIiOiIxIiwic2NvcGVzIjpbXX0.0v9Zj3j7ysMmZclM1zlQ2Mfgpk-AYOxnwTzfFYnBM7VBGfbjjfs6UpzhJvosSRFdkkhzGOZZAJh4DJR2hnCqrXf3sw4wphPzQqvRvDJVSNDwCk_Fl3gvDgl-VDoFJbDvqoNHwSXqCzoUV2y5KgIbpbu1-8n1QCvcWu_u0X4sVbk04frRaGtlrAz4g3iFVi2z2yGnslKY_h2cRMW3Jl6Ukmrfs7hgRevxlu_B5bvNcuwiWLfD8t38UmitNoYL4XAJirPk0Z3e9AqFLSaYIlTS5DhqLjYTzTpZ24auQCTFztvvvybMrNGi0ntiolKJl5Lti-sp___3JRLhJsMKbEkBifY0b3yJvWTVja9ekFR4BxCtmrWxuucLqniLxjA-sc1VIf6aqkEXFmheDFttKTjcf1oPigF5VFq2VxyUGzq50Or5TQZ6NxrQVG_2W556VwYaopfGkmCzOPqPx1FuVMmHerx_-OC1tTCBnMUQF3LJuVTSAZ5DGj9fH3EwFxoZ7aF9UsqCoY-90evqnEmvHFZ3vC2Em6hoBBkVirFMJrTERoazNGVm_3pUQszp672iTtb27hrQjYcK9iTRevyPBSCsu3bDMedIN_vjoG8mrOrJxNXN0KtP21UIXr93JTgQ9bLuwc4cQMijdz4A6Vkp-1jq1LJaq8eym4aD3fHf-hOQZaU'
  })
  constructor(
    private httpClient: HttpClient,
    private utilityService: UtilityService,
    private httpService: HttpService) { }

  // public getContacts(){
  //   //console.log(this.apiURL);
  //   return this.httpClient.get(`${this.apiURL}/get/profile`).pipe(
  //     map(data => {
  //         console.log('hi');
  //         return null;
  //     })
  // );

  getContact(){
   // return this.httpService.get('/get/profile').map((res:any) => res.data);
    return this.httpService.get('/get/profile');
  }
  

  sendFeedback(data){
    //return this.httpService.postForm('/feedback');
    return this.httpService.postJson('/feedback', data).subscribe(res=>{
      console.log(res)
      resolve(res);
    }, (err)=>{
      alert("post json error")
    });
  }

  getFaqs(){
    return this.httpService.get('/faq/list');
  }

  sendEmail(data) {
    return this.httpService.postJson('/update/email', data).subscribe(res=>{
      console.log(res)
      resolve(res);
    }, (err)=>{
      alert("post json error")
    });
  }

  sendUser(data){
    return this.httpService.postJson('/update/userid', data).subscribe(res=>{
      console.log(res)
      resolve(res);
    }, (err)=>{
      alert("post json error")
    });
  }  

  sendMobile(data){
    return this.httpService.postJson('/update/mobile', data).subscribe(res=>{
      resolve(res);
    }, (err)=>{
      alert("post json error")
    });
  }  

  sendName(data){
    return this.httpService.postJson('/update/profile/name', data).subscribe(res=>{
      resolve(res);
    }, (err)=>{
      alert("post json error")
    });
  }

  changePassword(data){
    return this.httpService.postJson('/change/password', data).subscribe(res=>{
      resolve(res);
    }, (err)=>{
      alert("post json error")
    });
  }

}
