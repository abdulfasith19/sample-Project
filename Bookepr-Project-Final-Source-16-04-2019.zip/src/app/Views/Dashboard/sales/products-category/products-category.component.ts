import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { ViewChild } from '@angular/core';

@Component({
  selector: 'app-products-category',
  templateUrl: './products-category.component.html',
  styleUrls: ['./products-category.component.scss']
})
export class ProductsCategoryComponent implements OnInit {

  // Table-Jason
  productcat: any;
  // estimation:any;
  // Table-Jason

  // Sorting
  order: string;
  reverse: boolean = false;
  
  sortedCollection: any[];
  // Sorting

  // Scrollbar
  public type: string = 'component';

  public disabled: boolean = false;

  public config: PerfectScrollbarConfigInterface = {};

  @ViewChild(PerfectScrollbarComponent) componentRef?: PerfectScrollbarComponent;
  @ViewChild(PerfectScrollbarDirective) directiveRef?: PerfectScrollbarDirective;

  // Scrollbar

  constructor(private orderPipe: OrderPipe) {

  }

  // Scrollbar
  public scrollToXY(x: number, y: number): void {
    if (this.type === 'directive' && this.directiveRef) {
      this.directiveRef.scrollTo(x, y, 500);
    }  else if (this.type === 'component' && this.componentRef && this.componentRef.directiveRef) {
      this.componentRef.directiveRef.scrollTo(x, y, 500);
    }
  }
  // Scrollbar

  ngOnInit() {
    this.productcat = [{
      "sno": '01',
      "name": "Mark Cho",
    },
    {
      "sno": '02',
      "name": "Cool Cars",
    },
    {
      "sno": '03',
      "name": "Mark Cho",
    },
    {
      "sno": '04',
      "name": "Cool Cars",
    },
    {
      "sno": '05',
      "name": "Mark Cho",
    },
    {
      "sno": '06',
      "name": "Mark Cho",
    },
    {
      "sno": '07',
      "name": "Cool Cars",
    },
    {
      "sno": '08',
      "name": "Mark Cho",
    },
    {
      "sno": '09',
      "name": "Cool Cars",
    },

    {
      "sno": '10',
      "name": "Mark Cho",
    },

    ]

    // console.log(this.collection)

  }


  // Sorting
  setOrder(value: string) {
    console.log(value)
    if (this.order === value) {
      this.reverse = !this.reverse;
    }

    this.order = value;
  }
  // Sorting

  // Scrollbar
  public onScrollEvent(event: any): void {

  }
  // Scrollbar
}
