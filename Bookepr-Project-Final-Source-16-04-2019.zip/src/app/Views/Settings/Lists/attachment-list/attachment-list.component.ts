import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';
@Component({
  selector: 'app-attachment-list',
  templateUrl: './attachment-list.component.html',
  styleUrls: ['./attachment-list.component.scss']
})
export class AttachmentListComponent implements OnInit {
  collection: any;
  p: number = 1;
  //collection: any[]; 
  order: string;
  reverse: boolean = false;
 
  sortedCollection: any[];
 
  constructor(private orderPipe: OrderPipe) {

  }

  ngOnInit() {
    this.collection = [{
      
      "sno":'01',
      "type": "Image",
      "name": "attachment",
      "size": "55.12KB",
      "upload": "7.20KB",
      "links": "34.80KB",
      "notes": "82.50KB"
    },
    {
      
      "sno":'02',
      "type": "Image",
      "name": "attachment",
      "size": "55.12KB",
      "upload": "7.20KB",
      "links": "34.80KB",
      "notes": "82.50KB"
    },
    {
      
      "sno":'03',
      "type": "Image",
      "name": "attachment",
      "size": "55.12KB",
      "upload": "7.20KB",
      "links": "34.80KB",
      "notes": "82.50KB"
    },
    {
      
      "sno":'04',
      "type": "Image",
      "name": "attachment",
      "size": "55.12KB",
      "upload": "7.20KB",
      "links": "34.80KB",
      "notes": "82.50KB"
    },
    {
      
      "sno":'05',
      "type": "Image",
      "name": "attachment",
      "size": "55.12KB",
      "upload": "7.20KB",
      "links": "34.80KB",
      "notes": "82.50KB"
    },
    {
      
      "sno":'06',
      "type": "Image",
      "name": "attachment",
      "size": "55.12KB",
      "upload": "7.20KB",
      "links": "34.80KB",
      "notes": "82.50KB"
    },
    {
      
      "sno":'07',
      "type": "Image",
      "name": "attachment",
      "size": "55.12KB",
      "upload": "7.20KB",
      "links": "34.80KB",
      "notes": "82.50KB"
    },
    {
      
      "sno":'08',
      "type": "Image",
      "name": "attachment",
      "size": "55.12KB",
      "upload": "7.20KB",
      "links": "34.80KB",
      "notes": "82.50KB"
    },
    {
      
      "sno":'09',
      "type": "Image",
      "name": "attachment",
      "size": "55.12KB",
      "upload": "7.20KB",
      "links": "34.80KB",
      "notes": "82.50KB"
    },

    {
      
      "sno":'10',
      "type": "Image",
      "name": "attachment",
      "size": "55.12KB",
      "upload": "7.20KB",
      "links": "34.80KB",
      "notes": "82.50KB"
    }

    ]
  }
    setOrder(value: string) {
      console.log(value)
      if (this.order === value) {
        this.reverse = !this.reverse;
      }
   
      this.order = value;
    }
   
   
   
   }
    
   
    