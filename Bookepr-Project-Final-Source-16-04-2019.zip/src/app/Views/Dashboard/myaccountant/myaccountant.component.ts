import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myaccountant',
  templateUrl: './myaccountant.component.html',
  styleUrls: ['./myaccountant.component.scss']
})
export class MyaccountantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
