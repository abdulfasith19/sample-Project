export class Categories {
    category_id: number;
    category_name: string;
    parent_id: number;
    imageUrl: any;    
    brand: number;
    th_mime_type: string;
    th_name: string;
    th_size: number;
    childs: any[];
    description: string;
    reated_at: string;
    updated_at: string;
    created_by: number;
    updated_by: number;
}
