import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxesCenterComponent } from './taxes-center.component';

describe('TaxesCenterComponent', () => {
  let component: TaxesCenterComponent;
  let fixture: ComponentFixture<TaxesCenterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaxesCenterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxesCenterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
