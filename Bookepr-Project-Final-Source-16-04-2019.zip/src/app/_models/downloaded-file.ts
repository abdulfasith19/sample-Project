export default interface DownloadedFile {
    blob: Blob;
    content_type: string;
    filename: string;
}
