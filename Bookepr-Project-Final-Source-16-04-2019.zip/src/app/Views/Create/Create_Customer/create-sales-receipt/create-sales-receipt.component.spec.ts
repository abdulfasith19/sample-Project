import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateSalesReceiptComponent } from './create-sales-receipt.component';

describe('CreateSalesReceiptComponent', () => {
  let component: CreateSalesReceiptComponent;
  let fixture: ComponentFixture<CreateSalesReceiptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateSalesReceiptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateSalesReceiptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
