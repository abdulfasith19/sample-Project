import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateReceiveComponent } from './create-receive.component';

describe('CreateReceiveComponent', () => {
  let component: CreateReceiveComponent;
  let fixture: ComponentFixture<CreateReceiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateReceiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateReceiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
