import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';


@Component({
  selector: 'app-create-bank-deposit',
  templateUrl: './create-bank-deposit.component.html',
  styleUrls: ['./create-bank-deposit.component.scss']
})
export class CreateBankDepositComponent implements OnInit {
  collection:any;
  category:any;
  p: number = 1;
 //collection: any[]; 
 order: string;
 reverse: boolean = false;

 sortedCollection: any[];

 constructor(private orderPipe: OrderPipe){ }


 ngOnInit() {
   this.collection =[{
     
      
       "received":"Cool Cars",
       "date":"15/02/2019",
       "type":"payment",
       "pay_method":"American Express",
       "memo":"Lorem Ipsum",
       "ref_num":"1023",
       "amount":"$1,675.52"
     
     },
   {
      "received":"Cool Cars",
       "date":"15/02/2019",
       "type":"payment",
       "pay_method":"British Airways",
       "memo":"Lorem Ipsum",
       "ref_num":"1023",
       "amount":"$1,675.52"
     
    
   }
 ]
 this.category =[{
     
      
  "sno":'01',
  "Received":"Army Bird Sanctuary",
  "Account":"Design Income",
  "Description":"Lorem Ipsum Is a Dummy Text",
  "pay_method":"American Express",
  "ref_num":"12345",
  "Amount":"$1,010.00"

},
{

"sno":'02',
"Received":"Army Bird Sanctuary",
"Account":"Fees Billed",
"Description":"Lorem Ipsum Is a Dummy Text",
"pay_method":"Cash",
"ref_num":"12346",
"Amount":"$101.00"

},
{

  "sno":'03',
  "Received":"Army Bird Sanctuary",
  "Account":"Design Income",
  "Description":"Lorem Ipsum Is a Dummy Text",
  "pay_method":"American Express",
  "ref_num":"12345",
  "Amount":"$1,010.00"

},
{

  "sno":'04',
  "Received":"Army Bird Sanctuary",
  "Account":"Fees Billed",
  "Description":"Lorem Ipsum Is a Dummy Text",
  "pay_method":"Cash",
  "ref_num":"12346",
  "Amount":"$101.00"

}

]
   console.log(this.collection)
   console.log(this.category)
 }

 setOrder(value: string) {
   console.log(value)
   if (this.order === value) {
     this.reverse = !this.reverse;
   }

   this.order = value;
 }



}
 

