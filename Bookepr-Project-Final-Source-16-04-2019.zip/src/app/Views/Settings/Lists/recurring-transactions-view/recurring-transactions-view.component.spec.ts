import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecurringTransactionsViewComponent } from './recurring-transactions-view.component';

describe('RecurringTransactionsViewComponent', () => {
  let component: RecurringTransactionsViewComponent;
  let fixture: ComponentFixture<RecurringTransactionsViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecurringTransactionsViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecurringTransactionsViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
