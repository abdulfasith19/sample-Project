export class Profile {

	id: number;
	user_id: string;
	email_address: string;
	password: string;
	new_password: string;
	old_password: string;
	confirm_password: string;
	first_name: string;
	last_name: string;
	contact_number: string;
	user_type: string;
	profile_image: string;
	country: string;
	address: string;
	city: string;
	state: string;
	zip_code: number;
	created_at: string;
	updated_at: string;
}