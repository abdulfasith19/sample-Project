import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateBankDepositComponent } from './create-bank-deposit.component';

describe('CreateBankDepositComponent', () => {
  let component: CreateBankDepositComponent;
  let fixture: ComponentFixture<CreateBankDepositComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateBankDepositComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateBankDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
