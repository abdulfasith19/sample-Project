import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthenticationService } from '../_services/index';
import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  returnUrl: string;
  email:string;
  password:string;


  constructor(private formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,
    private route: ActivatedRoute,
    private router: Router,
    private toastr: ToastrService) { }

  ngOnInit() {

    this.loginForm = this.formBuilder.group({
      email: [null, [Validators.required, Validators.minLength(4)]],
      password: [null, [Validators.required]]
    });
    this.authenticationService.logout();

    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/Dashboards/Dashboard';
  }
  login(){
    console.log(this.loginForm);
    console.log('dsfgdsgdsg');
   // this.router.navigate(['/Dashboards/Dashboard']);
  }
  onSubmit() {
    console.log(this.loginForm.value);
    this.authenticationService.login(this.loginForm.value.email,
      this.loginForm.value.password).subscribe((data) => {
        this.toastr.success('Login', "Login success");
        this.router.navigate([this.returnUrl]);
      });
  }

}
