import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MDBBootstrapModule } from 'angular-bootstrap-md';

import { NgxPaginationModule } from 'ngx-pagination';
import { OrderModule } from 'ngx-order-pipe';
import { PerfectScrollbarModule, PerfectScrollbarConfigInterface,
  PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';

import { DashboardComponent } from './Dashboard/dashboard/dashboard.component';
import { BankingComponent } from './Dashboard/banking/banking.component';
import { SalesComponent } from './Dashboard/sales/sales.component';
import { ExpensesComponent } from './Dashboard/expenses/expenses.component';
import { ReportsComponent } from './Dashboard/reports/reports.component';
import { TaxesComponent } from './Dashboard/taxes/taxes.component';
import { AccountingComponent } from './Dashboard/accounting/accounting.component';
import { MyaccountantComponent } from './Dashboard/myaccountant/myaccountant.component';

import { UserProfileComponent } from './Profile/user-profile/user-profile.component';
import { UserFeedbacksComponent } from './Profile/user-feedbacks/user-feedbacks.component';
import { PrivacyComponent } from './Profile/privacy/privacy.component';
import { FaqComponent } from './Profile/faq/faq.component';
import { TaxesViewComponent } from './Dashboard/taxes/taxes-view/taxes-view.component';
import { VendorsComponent } from './Dashboard/expenses/vendors/vendors.component';
import { VendorsInformationComponent } from './Dashboard/expenses/vendors-information/vendors-information.component';
import { NewRuleComponent } from './Dashboard/banking/new-rule/new-rule.component';
import { ConnectAccountComponent } from './Dashboard/banking/connect-account/connect-account.component';
import { SalesCustomerComponent } from './Dashboard/sales/sales-customer/sales-customer.component';
import { SalesCustomerInformationComponent } from './Dashboard/sales/sales-customer-information/sales-customer-information.component';
import { ProductsCategoryComponent } from './Dashboard/sales/products-category/products-category.component';
import { ProductsAndServicesTypesComponent } from './Dashboard/sales/products-and-services-types/products-and-services-types.component';
import { ReconcileSummaryComponent } from './Dashboard/accounting/reconcile-summary/reconcile-summary.component';
import { ReconcileHistoryComponent } from './Dashboard/accounting/reconcile-history/reconcile-history.component';
import { ReconcileCheckingComponent } from './Dashboard/accounting/reconcile-checking/reconcile-checking.component';
import { BankRegisterComponent } from './Dashboard/accounting/bank-register/bank-register.component';

import { LinechartComponent } from './Charts/linechart/linechart.component';
import { BarchartComponent } from './Charts/barchart/barchart.component';
import { PiechartComponent } from './Charts/piechart/piechart.component';
import { DoughnutchartComponent } from './Charts/doughnutchart/doughnutchart.component';

// nbx-bootstrap
import { TabsModule } from 'ngx-bootstrap/tabs';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { TaxesCenterComponent } from './Dashboard/taxes/taxes-center/taxes-center.component';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  wheelPropagation: true
};
@NgModule({
  declarations: [
    DashboardComponent,
    BankingComponent,
    SalesComponent,
    ExpensesComponent,
    ReportsComponent,
    TaxesComponent,
    AccountingComponent,
    MyaccountantComponent,
    UserProfileComponent,
    UserFeedbacksComponent,
    PrivacyComponent,
    FaqComponent,
    TaxesViewComponent,
    VendorsComponent,
    VendorsInformationComponent,
    NewRuleComponent,
    ConnectAccountComponent,
    SalesCustomerComponent,
    SalesCustomerInformationComponent,
    ProductsCategoryComponent,
    ProductsAndServicesTypesComponent,
    ReconcileSummaryComponent,
    ReconcileHistoryComponent,
    ReconcileCheckingComponent,
    BankRegisterComponent,
    LinechartComponent,
    BarchartComponent,
    PiechartComponent,
    DoughnutchartComponent,
    TaxesCenterComponent
  
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    MDBBootstrapModule.forRoot(),
    TabsModule.forRoot(),
    TimepickerModule.forRoot(),
    BsDatepickerModule.forRoot(),
    NgxPaginationModule,
    OrderModule,
    AccordionModule.forRoot(),
    PerfectScrollbarModule
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ],
  schemas: [ NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA ]
}) 
export class ViewModule { }
