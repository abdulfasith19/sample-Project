import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-users',
  templateUrl: './add-users.component.html',
  styleUrls: ['./add-users.component.scss']
})
export class AddUsersComponent implements OnInit {
  userTypeView = true;
  accessRightView = false;
  userSettingView = false;
  userInfoView = false;

  usertype1 = false;
  usertype2 = false;
  usertype3 = false;

  
  constructor() { }
  ngOnInit() {
  }
  userType(){
    this.userTypeView = false;
    this.accessRightView = true;
    this.userSettingView = false;
    this.userInfoView = false;
    this.usertype1 = true;
  }
  accessright(){
    this.userTypeView = false;
    this.accessRightView = false;
    this.userSettingView = true;
    this.userInfoView = false;
    this.usertype2 = true;
  }
  userSetting(){
    this.userTypeView = false;
    this.accessRightView = false;
    this.userSettingView = false;
    this.userInfoView = true;
    this.usertype3 = true;
  }

  accessrightBack(){
    this.userTypeView = true;
    this.accessRightView = false;
    this.userSettingView = false;
    this.userInfoView = false;
    this.usertype1 = false;
  }
  userSettingBack(){
    this.userTypeView = false;
    this.accessRightView = true;
    this.userSettingView = false;
    this.userInfoView = false;
    this.usertype2 = false;
  }
  userInfoBack(){
    this.userTypeView = false;
    this.accessRightView = false;
    this.userSettingView = true;
    this.userInfoView = false;
    this.usertype3 = false;
  }
  

}
