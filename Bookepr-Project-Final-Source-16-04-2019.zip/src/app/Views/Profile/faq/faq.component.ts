import { Component, OnInit,Input, Output, EventEmitter} from '@angular/core';
import { ContentService } from '../../../_services'
import { ProfileService } from 'src/app/services/profile.service';
import {FormGroup, FormControl,FormBuilder,Validators } from '@angular/forms';
import { Faq } from 'src/app/_models/Faq';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss'],
  providers: [ProfileService]
})
export class FaqComponent implements OnInit {

  faqs: Faq 
  public show:boolean = false;
  public buttonName:any = 'Show';

  constructor(private contentService: ProfileService ) { }

  ngOnInit() {
    this.contentService.getFaqs().subscribe((data)=>{
      console.log(data);
      this.faqs = data;
    });
  }

  


}
