import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';
@Component({
  selector: 'app-lists-terms',
  templateUrl: './lists-terms.component.html',
  styleUrls: ['./lists-terms.component.scss']
})
export class ListsTermsComponent implements OnInit {

collection: any;
p: number = 1;
//collection: any[]; 
order: string;
reverse: boolean = false;

sortedCollection: any[];

constructor(private orderPipe: OrderPipe) {

}

ngOnInit() {
  this.collection = [{
    
    "sno":'01',
    "name": "Due on Receipt"
  },
  {
    
    "sno":'02',
    "name": "Due on Receipt"
  },
  {
    
    "sno":'03',
    "name": "Due on Receipt"
  },
  {
    
    "sno":'04',
    "name": "Due on Receipt"
  },
  {
    
    "sno":'05',
    "name": "Due on Receipt"
  },
  {
    
    "sno":'06',
    "name": "Due on Receipt"
  },
  {
    
    "sno":'07',
    "name": "Due on Receipt"
  },
  {
    
    "sno":'08',
    "name": "Due on Receipt"
  },
  {
    
    "sno":'09',
    "name": "Due on Receipt"
  },

  {
    
    "sno":'10',
    "name": "Due on Receipt"
  }

  ]
}
  setOrder(value: string) {
    console.log(value)
    if (this.order === value) {
      this.reverse = !this.reverse;
    }
 
    this.order = value;
  }
 
 
 
 }
  
 

