import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-linechart',
  templateUrl: './linechart.component.html',
  styleUrls: ['./linechart.component.scss']
})
export class LinechartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  public chartType: string = 'line';
  
  public chartDatasets = [
    { data: [65, 59, 80, 81, 56, 55, 40], label: 'Income' },
    { data: [28, 48, 40, 19, 86, 27, 90], label: 'Expense' }
    
  ];

  public chartLabels = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];

  public chartColors = [
    {
      backgroundColor: 'transparent',
      borderColor: 'rgba(63, 168, 233, .7)',
      borderWidth: 2,
      pointBorderColor: "#62baf0",
      pointBackgroundColor: "#fff",
    
    },
   
    {
      backgroundColor: 'transparent',
      borderColor: 'rgba(221, 233, 87, .7)',
      borderWidth: 2,
      pointBorderColor: "#9bf014",
      pointBackgroundColor: "#fff",
      options: {
        scales: {
          yAxes: [{
            ticks: {
              fontColor: 'red'
            }
          }]
        }
      }
 
    }
  ];

  public chartOptions: any = {
    responsive: true,
  };


  public chartClicked(e: any): void { }
  public chartHovered(e: any): void { }
}
