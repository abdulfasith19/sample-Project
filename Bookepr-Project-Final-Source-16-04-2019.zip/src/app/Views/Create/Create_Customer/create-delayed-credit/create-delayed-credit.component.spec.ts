import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateDelayedCreditComponent } from './create-delayed-credit.component';

describe('CreateDelayedCreditComponent', () => {
  let component: CreateDelayedCreditComponent;
  let fixture: ComponentFixture<CreateDelayedCreditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateDelayedCreditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateDelayedCreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
