import { Component, OnInit } from '@angular/core';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { ViewChild } from '@angular/core';
@Component({
  selector: 'app-custom-form-edit',
  templateUrl: './custom-form-edit.component.html',
  styleUrls: ['./custom-form-edit.component.scss']
})
export class CustomFormEditComponent implements OnInit {

// Scrollbar
public type: string = 'component';

public disabled: boolean = false;

public config: PerfectScrollbarConfigInterface = {};

@ViewChild(PerfectScrollbarComponent) componentRef?: PerfectScrollbarComponent;
@ViewChild(PerfectScrollbarDirective) directiveRef?: PerfectScrollbarDirective;

// Scrollbar

  constructor() { }

// Scrollbar
public scrollToXY(x: number, y: number): void {
  if (this.type === 'directive' && this.directiveRef) {
    this.directiveRef.scrollTo(x, y, 500);
  }  else if (this.type === 'component' && this.componentRef && this.componentRef.directiveRef) {
    this.componentRef.directiveRef.scrollTo(x, y, 500);
  }
}
// Scrollbar

  ngOnInit() {
  }
  status: boolean = false;
  status2: boolean = false;
  status3: boolean = false;
  status4: boolean = false;
  status5: boolean = false;
  status6: boolean = false;
  status7: boolean = false;
  status8: boolean = false;
  status9: boolean = false;
  nameEvent(){
      this.status = !this.status;       
  }
  tempEvent(){
    this.status2 = !this.status2;
  }
  editEvent(){
    this.status3 = !this.status3;
  }
  colorEvent(){
    this.status4 = !this.status4;
  }
  fontEvent(){
    this.status5 = !this.status5;
  }
  editallEvent(){
    this.status6 = !this.status6;
  }
  emailallEvent(){
    this.status7 = !this.status7;
  }
  emailEvent(){
    this.status8 = !this.status8;
  }
  remainemailEvent(){
    this.status9 = !this.status9;
  }

  // Scrollbar
  public onScrollEvent(event: any): void {

  }
  // Scrollbar

}
