import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-import-customers',
  templateUrl: './import-customers.component.html',
  styleUrls: ['./import-customers.component.scss']
})
export class ImportCustomersComponent implements OnInit {
  excelImport = true;
  mapdataImport = false;
  finalImport = false;

  importtype1 = false;
  importtype2 = false;

  constructor() { }

  ngOnInit() {
  }
excelImportView(){
  this.excelImport = false
  this.mapdataImport = true;
  this.finalImport = false;
  this.importtype1 = true;

}
mapdataImportView(){
  this.excelImport = false
  this.mapdataImport = false;
  this.finalImport = true;
  this.importtype2 = true;
}
innerImportView(){
  this.excelImport = false
  this.mapdataImport = false;
  this.finalImport = true;
  this.importtype2 = true;
}
mapdataImportBack(){
  this.excelImport = true
  this.mapdataImport = false;
  this.finalImport = false;
  this.importtype1 = false;
}
innerImportBack(){
  this.excelImport = false
  this.mapdataImport = true;
  this.finalImport = false;
  this.importtype2 = false;
}
}
