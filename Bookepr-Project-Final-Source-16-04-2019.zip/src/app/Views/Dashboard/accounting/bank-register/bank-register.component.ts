import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';
import {
  PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective
} from 'ngx-perfect-scrollbar';
import { ViewChild } from '@angular/core'
@Component({
  selector: 'app-bank-register',
  templateUrl: './bank-register.component.html',
  styleUrls: ['./bank-register.component.scss']
})
export class BankRegisterComponent implements OnInit {

// Table-Jason
collection: any;
reconcilechecking: any;

// estimation:any;
// Table-Jason

// Sorting
order: string;
reverse: boolean = false;


allSales: boolean = true;
estimate: boolean = false;
unbill: boolean = false;
overDue: boolean = false;
openInvoice: boolean = false;
paid: boolean = false;



sortedCollection: any[];
// Sorting

// Scrollbar
public type: string = 'component';

public disabled: boolean = false;

public config: PerfectScrollbarConfigInterface = {};

@ViewChild(PerfectScrollbarComponent) componentRef?: PerfectScrollbarComponent;
@ViewChild(PerfectScrollbarDirective) directiveRef?: PerfectScrollbarDirective;

// Scrollbar

constructor(private orderPipe: OrderPipe) {

}

// Scrollbar
public scrollToXY(x: number, y: number): void {
  if (this.type === 'directive' && this.directiveRef) {
    this.directiveRef.scrollTo(x, y, 500);
  }  else if (this.type === 'component' && this.componentRef && this.componentRef.directiveRef) {
    this.componentRef.directiveRef.scrollTo(x, y, 500);
  }
}
// Scrollbar

ngOnInit() {

  this.reconcilechecking = [{
    "sno": '01',
    "date": '02/25/2019',
    "type": 'Receive Payment',
    "refno": "205",
    "account": "Design income",
    "payment": "$ 125.00",
  },

  {
    "sno": '02',
    "date": '02/25/2019',
    "type": 'Receive Payment',
    "refno": "205",
    "account": "Design income",
    "payment": "$ 125.00",
  },

  {
    "sno": '03',
    "date": '02/25/2019',
    "type": 'Receive Payment',
    "refno": "205",
    "account": "Design income",
    "payment": "$ 125.00",
  },

  {
    "sno": '04',
    "date": '02/25/2017',
    "type": 'Receive Payment',
    "refno": "205",
    "account": "Design income",
    "payment": "$ 125.00",
  },

  {
    "sno": '05',
    "date": '02/25/2017',
    "type": 'Receive Payment',
    "refno": "205",
    "account": "Design income",
    "payment": "$ 125.00",
  },

  {
    "sno": '06',
    "date": '02/25/2019',
    "type": 'Receive Payment',
    "refno": "205",
    "account": "Design income",
    "payment": "$ 125.00",
  },

  {
    "sno": '07',
    "date": '02/25/2019',
    "type": 'Receive Payment',
    "refno": "205",
    "account": "Design income",
    "payment": "$ 125.00",
  },

  {
    "sno": '08',
    "date": '02/25/2019',
    "type": 'Receive Payment',
    "refno": "205",
    "account": "Design income",
    "payment": "$ 125.00",
  },

  {
    "sno": '09',
    "date": '02/25/2019',
    "type": 'Receive Payment',
    "refno": "205",
    "account": "Design income",
    "payment": "$ 125.00",
  },

  {
    "sno": '10',
    "date": '02/25/2019',
    "type": 'Receive Payment',
    "refno": "205",
    "account": "Design income",
    "payment": "$ 125.00",
  },

  {
    "sno": '11',
    "date": '02/25/2019',
    "type": 'Receive Payment',
    "refno": "205",
    "account": "Design income",
    "payment": "$ 125.00",
  },

  ]

  
  // console.log(this.collection)

}


// Sorting
setOrder(value: string) {
  console.log(value)
  if (this.order === value) {
    this.reverse = !this.reverse;
  }

  this.order = value;
}
// Sorting


// Scrollbar
public onScrollEvent(event: any): void {

}
// Scrollbar
}
