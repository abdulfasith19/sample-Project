import { Injectable } from '@angular/core';

import { HttpClient,HttpHeaders,HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { filter, finalize, map, catchError } from 'rxjs/operators';
import { UtilityService, HttpService } from '../_services';

@Injectable({
  providedIn: 'root'
})
export class UserProfileService {

  constructor(private httpClient: HttpClient,
    private utilityService: UtilityService,
    private httpService: HttpService) { }

    getContact(){
      return this.httpService.get('/get/profile');
    }
}
