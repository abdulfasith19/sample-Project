import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';
import {
  PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective
} from 'ngx-perfect-scrollbar';
import { ViewChild } from '@angular/core'
@Component({
  selector: 'app-reconcile-history',
  templateUrl: './reconcile-history.component.html',
  styleUrls: ['./reconcile-history.component.scss']
})
export class ReconcileHistoryComponent implements OnInit {
// Table-Jason
collection: any;
reconcilehistory: any;

// estimation:any;
// Table-Jason

// Sorting
order: string;
reverse: boolean = false;


allSales: boolean = true;
estimate: boolean = false;
unbill: boolean = false;
overDue: boolean = false;
openInvoice: boolean = false;
paid: boolean = false;



sortedCollection: any[];
// Sorting

// Scrollbar
public type: string = 'component';

public disabled: boolean = false;

public config: PerfectScrollbarConfigInterface = {};

@ViewChild(PerfectScrollbarComponent) componentRef?: PerfectScrollbarComponent;
@ViewChild(PerfectScrollbarDirective) directiveRef?: PerfectScrollbarDirective;

// Scrollbar

constructor(private orderPipe: OrderPipe) {

}

// Scrollbar
public scrollToXY(x: number, y: number): void {
  if (this.type === 'directive' && this.directiveRef) {
    this.directiveRef.scrollTo(x, y, 500);
  }  else if (this.type === 'component' && this.componentRef && this.componentRef.directiveRef) {
    this.componentRef.directiveRef.scrollTo(x, y, 500);
  }
}
// Scrollbar

ngOnInit() {

  this.collection = [{
    "sno": '01',
    "name": 'Checking',
    "type": "Bank",
    "detail": "Checking",
    "quickbalance": "$ 350.00",
    "bankbalance": "$ 350.00",
    "action": "View Register",
  },

  {
    "sno": '02',
    "name": 'Savings',
    "type": "Expenses",
    "detail": "Savings",
    "quickbalance": "$ 350.00",
    "bankbalance": "$ 350.00",
    "action": "View Register",
  },

  {
    "sno": '03',
    "name": 'Inventory Asset',
    "type": "Fixed Assets",
    "detail": "Credit Card",
    "quickbalance": "$ 350.00",
    "bankbalance": "$ 350.00",
    "action": "Run Report",
  },

  {
    "sno": '04',
    "name": 'Mastercard',
    "type": "Credit Card",
    "detail": "Other Primary Income",
    "quickbalance": "$ 240.00",
    "bankbalance": "$ 240.00",
    "action": "Run Report",
  },

  {
    "sno": '05',
    "name": 'Notes Payable',
    "type": "Equity",
    "detail": "Other Miscellaneous...",
    "quickbalance": "$ 400.00",
    "bankbalance": "$ 400.00",
    "action": "Run Report",
  },

  {
    "sno": '06',
    "name": 'Checking',
    "type": "Bank",
    "detail": "Checking",
    "quickbalance": "$ 350.00",
    "bankbalance": "$ 350.00",
    "action": "View Register",
  },

  {
    "sno": '07',
    "name": 'Savings',
    "type": "Expenses",
    "detail": "Savings",
    "quickbalance": "$ 350.00",
    "bankbalance": "$ 350.00",
    "action": "View Register",
  },

  {
    "sno": '08',
    "name": 'Inventory Asset',
    "type": "Fixed Assets",
    "detail": "Credit Card",
    "quickbalance": "$ 350.00",
    "bankbalance": "$ 350.00",
    "action": "Run Report",
  },

  {
    "sno": '09',
    "name": 'Mastercard',
    "type": "Credit Card",
    "detail": "Other Primary Income",
    "quickbalance": "$ 240.00",
    "bankbalance": "$ 240.00",
    "action": "Run Report",
  },

  {
    "sno": '10',
    "name": 'Notes Payable',
    "type": "Equity",
    "detail": "Other Miscellaneous...",
    "quickbalance": "$ 400.00",
    "bankbalance": "$ 400.00",
    "action": "Run Report",
  },

  {
    "sno": '11',
    "name": 'Checking',
    "type": "Bank",
    "detail": "Checking",
    "quickbalance": "$ 350.00",
    "bankbalance": "$ 350.00",
    "action": "View Register",
  },
  ]

  this.reconcilehistory = [{
    "sno": '01',
    "statedate": '(12/02/2019)',
    "reconciledate": '(12/02/2019)',
    "endbalance": "$ 125.00",
    "changes": "0.00",
    "autodate": "$ 125.00", 
  },
 
  {
    "sno": '02',
    "statedate": '(12/02/2019)',
    "reconciledate": '(12/02/2019)',
    "endbalance": "$ 125.00",
    "changes": "0.00",
    "autodate": "$ 125.00", 
  },

  {
    "sno": '03',
    "statedate": '(12/02/2019)',
    "reconciledate": '(12/02/2019)',
    "endbalance": "$ 125.00",
    "changes": "0.00",
    "autodate": "$ 125.00", 
  },

  {
    "sno": '04',
    "statedate": '(12/02/2019)',
    "reconciledate": '(12/02/2019)',
    "endbalance": "$ 125.00",
    "changes": "0.00",
    "autodate": "$ 125.00", 
  },

  {
    "sno": '05',
    "statedate": '(12/02/2019)',
    "reconciledate": '(12/02/2019)',
    "endbalance": "$ 125.00",
    "changes": "0.00",
    "autodate": "$ 125.00", 
  },

  {
    "sno": '06',
    "statedate": '(12/02/2019)',
    "reconciledate": '(12/02/2019)',
    "endbalance": "$ 125.00",
    "changes": "0.00",
    "autodate": "$ 125.00", 
  },

  {
    "sno": '07',
    "statedate": '(12/02/2019)',
    "reconciledate": '(12/02/2019)',
    "endbalance": "$ 125.00",
    "changes": "0.00",
    "autodate": "$ 125.00", 
  },

  {
    "sno": '08',
    "statedate": '(12/02/2019)',
    "reconciledate": '(12/02/2019)',
    "endbalance": "$ 125.00",
    "changes": "0.00",
    "autodate": "$ 125.00", 
  },

  {
    "sno": '09',
    "statedate": '(12/02/2019)',
    "reconciledate": '(12/02/2019)',
    "endbalance": "$ 125.00",
    "changes": "0.00",
    "autodate": "$ 125.00", 
  },

  {
    "sno": '10',
    "statedate": '(12/02/2019)',
    "reconciledate": '(12/02/2019)',
    "endbalance": "$ 125.00",
    "changes": "0.00",
    "autodate": "$ 125.00", 
  },

  
  ]
  // console.log(this.collection)

}


// Sorting
setOrder(value: string) {
  console.log(value)
  if (this.order === value) {
    this.reverse = !this.reverse;
  }

  this.order = value;
}
// Sorting


// Scrollbar
public onScrollEvent(event: any): void {

}
// Scrollbar
}
