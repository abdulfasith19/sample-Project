import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';
import {
  PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective
} from 'ngx-perfect-scrollbar';
import { ViewChild } from '@angular/core';

@Component({
  selector: 'app-sales',
  templateUrl: './sales.component.html',
  styleUrls: ['./sales.component.scss']
})
export class SalesComponent implements OnInit {


  // Table-Jason
  collection: any;
  invoice: any;
  customerlist: any;
  productservices: any;
  // estimation:any;
  // Table-Jason

  // Sorting
  order: string;
  reverse: boolean = false;


  allSales: boolean = true;
  estimate: boolean = false;
  unbill: boolean = false;
  overDue: boolean = false;
  openInvoice: boolean = false;
  paid: boolean = false;



  sortedCollection: any[];
  // Sorting

  // Scrollbar
  public type: string = 'component';

  public disabled: boolean = false;

  public config: PerfectScrollbarConfigInterface = {};

  @ViewChild(PerfectScrollbarComponent) componentRef?: PerfectScrollbarComponent;
  @ViewChild(PerfectScrollbarDirective) directiveRef?: PerfectScrollbarDirective;

  // Scrollbar

  constructor(private orderPipe: OrderPipe) {

  }

  // Scrollbar
  public scrollToXY(x: number, y: number): void {
    if (this.type === 'directive' && this.directiveRef) {
      this.directiveRef.scrollTo(x, y, 500);
    }  else if (this.type === 'component' && this.componentRef && this.componentRef.directiveRef) {
      this.componentRef.directiveRef.scrollTo(x, y, 500);
    }
  }
  // Scrollbar

  ngOnInit() {

    this.collection = [{
      "checkbox": '01',
      "sno": '01',
      "date": '(12/02/2019)',
      "type": "1020",
      "no": "Invoice",
      "customer": "Mark Cho",
      "duedate": "02/13/2019",
      "balance": "$314.28",
      "total": "$78.20",
      "status": "open"
    },
    {
      "checkbox": '02',
      "sno": '02',
      "date": '(13/02/2019)',
      "type": "1021",
      "no": "Invoice",
      "customer": "Cool Cars",
      "duedate": "03/13/2019",
      "balance": "$314.28",
      "total": "$78.20",
      "status": "closed"
    },
    {
      "checkbox": '03',
      "sno": '03',
      "date": '(14/02/2019)',
      "type": "1022",
      "no": "Invoice",
      "customer": "Mark Cho",
      "duedate": "04/13/2019",
      "balance": "$314.28",
      "total": "$78.20",
      "status": "paid"
    },
    {
      "checkbox": '04',
      "sno": '04',
      "date": '(15/02/2019)',
      "type": "1023",
      "no": "Invoice",
      "customer": "Cool Cars",
      "duedate": "05/13/2019",
      "balance": "$314.28",
      "total": "$78.20",
      "status": "overdue"
    },
    {
      "checkbox": '06',
      "sno": '05',
      "date": '(16/02/2019)',
      "type": "1024",
      "no": "Invoice",
      "customer": "Mark Cho",
      "duedate": "06/13/2019",
      "balance": "$314.28",
      "total": "$78.20",
      "status": "open"
    },
    {
      "checkbox": '07',
      "sno": '06',
      "date": '(17/02/2019)',
      "type": "1025",
      "no": "Invoice",
      "customer": "Mark Cho",
      "duedate": "07/13/2019",
      "balance": "$314.28",
      "total": "$78.20",
      "status": "open"
    },
    {
      "checkbox": '08',
      "sno": '07',
      "date": '(18/02/2019)',
      "type": "1026",
      "no": "Invoice",
      "customer": "Cool Cars",
      "duedate": "08/13/2019",
      "balance": "$314.28",
      "total": "$78.20",
      "status": "open"
    },
    {
      "checkbox": '09',
      "sno": '08',
      "date": '(19/02/2019)',
      "type": "1027",
      "no": "Invoice",
      "customer": "Mark Cho",
      "duedate": "09/13/2019",
      "balance": "$314.28",
      "total": "$78.20",
      "status": "open"
    },
    {
      "checkbox": '10',
      "sno": '09',
      "date": '(20/02/2019)',
      "type": "1028",
      "no": "Invoice",
      "customer": "Cool Cars",
      "duedate": "10/13/2019",
      "balance": "$314.28",
      "total": "$78.20",
      "status": "open"
    },

    {
      "checkbox": '11',
      "sno": '10',
      "date": '(21/02/2019)',
      "type": "1029",
      "no": "Invoice",
      "customer": "Mark Cho",
      "duedate": "11/13/2019",
      "balance": "$314.28",
      "total": "$78.20",
      "status": "open"
    },

    ]


    this.invoice = [{
      "checkbox": '01',
      "sno": '01',
      "date": '(12/02/2019)',
      "type": "1020",
      "customer": "Mark Cho",
      "duedate": "02/13/2019",
      "total": "$78.20",
      "status": "open"
    },
    {
      "checkbox": '02',
      "sno": '02',
      "date": '(13/02/2019)',
      "type": "1021",
      "customer": "Cool Cars",
      "duedate": "03/13/2019",
      "total": "$78.20",
      "status": "closed"
    },
    {
      "checkbox": '03',
      "sno": '03',
      "date": '(14/02/2019)',
      "type": "1022",
      "customer": "Mark Cho",
      "duedate": "04/13/2019",
      "total": "$78.20",
      "status": "paid"
    },
    {
      "checkbox": '04',
      "sno": '04',
      "date": '(15/02/2019)',
      "type": "1023",
      "customer": "Cool Cars",
      "duedate": "05/13/2019",
      "total": "$78.20",
      "status": "overdue"
    },
    {
      "checkbox": '06',
      "sno": '05',
      "date": '(16/02/2019)',
      "type": "1024",
      "customer": "Mark Cho",
      "duedate": "06/13/2019",
      "total": "$78.20",
      "status": "open"
    },
    {
      "checkbox": '07',
      "sno": '06',
      "date": '(17/02/2019)',
      "type": "1025",
      "customer": "Mark Cho",
      "duedate": "07/13/2019",
      "total": "$78.20",
      "status": "open"
    },
    {
      "checkbox": '08',
      "sno": '07',
      "date": '(18/02/2019)',
      "type": "1026",
      "customer": "Cool Cars",
      "duedate": "08/13/2019",
      "total": "$78.20",
      "status": "open"
    },
    {
      "checkbox": '09',
      "sno": '08',
      "date": '(19/02/2019)',
      "type": "1027",
      "customer": "Mark Cho",
      "duedate": "09/13/2019",
      "total": "$78.20",
      "status": "open"
    },
    {
      "checkbox": '10',
      "sno": '09',
      "date": '(20/02/2019)',
      "type": "1028",
      "customer": "Cool Cars",
      "duedate": "10/13/2019",
      "total": "$78.20",
      "status": "open"
    },

    {
      "checkbox": '11',
      "sno": '10',
      "date": '(21/02/2019)',
      "type": "1029",
      "customer": "Mark Cho",
      "duedate": "11/13/2019",
      "total": "$78.20",
      "status": "open"
    },

    ]


    this.customerlist = [{
      "checkbox": '01',
      "sno": '01',
      "phone": "(650) 554-1479",
      "balance": "$350",
    },
    {
      "checkbox": '02',
      "sno": '02',
      "phone": "(650) 554-1479",
      "balance": "$350",
    },
    {
      "checkbox": '03',
      "sno": '03',
      "phone": "(650) 554-1479",
      "balance": "$350",
    },
    {
      "checkbox": '04',
      "sno": '04',
      "phone": "(650) 554-1479",
      "balance": "$350",
    },
    {
      "checkbox": '06',
      "sno": '05',
      "phone": "(650) 554-1479",
      "balance": "$350",
    },
    {
      "checkbox": '07',
      "sno": '06',
      "phone": "(650) 554-1479",
      "balance": "$350",
    },
    {
      "checkbox": '08',
      "sno": '07',
      "phone": "(650) 554-1479",
      "balance": "$350",
    },
    {
      "checkbox": '09',
      "sno": '08',
      "phone": "(650) 554-1479",
      "balance": "$350",
    },
    {
      "checkbox": '10',
      "sno": '09',
      "phone": "(650) 554-1479",
      "balance": "$350",
    },

    {
      "checkbox": '11',
      "sno": '10',
      "phone": "(650) 554-1479",
      "balance": "$350",
    },

    ]



    this.productservices = [{
      "checkbox": '01',
      "sno": '01',
      "sku": "S867-56",
      "desc": "Custom Design...",
      "cost": "$350",
      "taxable": "001",
      "qty": "25",
      "name":"Design",
    },
    {
      "checkbox": '02',
      "sno": '02',
      "sku": "S867-56",
      "desc": "Custom Design...",
      "cost": "$350",
      "taxable": "002",
      "qty": "25",
      "name":"Fountain",
    },
    {
      "checkbox": '03',
      "sno": '03',
      "sku": "S867-56",
      "desc": "Custom Design...",
      "cost": "$350",
      "taxable": "003",
      "qty": "25",
      "name":"Land Scaping",
    },
    {
      "checkbox": '04',
      "sno": '04',
      "sku": "S867-56",
      "desc": "Custom Design...",
      "cost": "$350",
      "taxable": "004",
      "qty": "25",
      "name":"Sprinklers",
    },
    {
      "checkbox": '06',
      "sno": '05',
      "sku": "S867-56",
      "desc": "Custom Design...",
      "cost": "$350",
      "taxable": "006",
      "qty": "25",
      "name":"design",
    },
    {
      "checkbox": '07',
      "sno": '06',
      "sku": "S867-56",
      "desc": "Custom Design...",
      "cost": "$350",
      "taxable": "007",
      "qty": "25",
      "name":"Fountain",
    },
    {
      "checkbox": '08',
      "sno": '07',
      "sku": "S867-56",
      "desc": "Custom Design...",
      "cost": "$350",
      "taxable": "008",
      "qty": "25",
      "name":"Land Scaping",
    },
    {
      "checkbox": '09',
      "sno": '08',
      "sku": "S867-56",
      "desc": "Custom Design...",
      "cost": "$350",
      "taxable": "009",
      "qty": "25",
      "name":"Sprinklers",
    },
    {
      "checkbox": '10',
      "sno": '09',
      "sku": "S867-56",
      "desc": "Custom Design...",
      "cost": "$350",
      "taxable": "0010",
      "qty": "25",
      "name":"design",
    },

    {
      "checkbox": '11',
      "sno": '10',
      "sku": "S867-56",
      "desc": "Custom Design...",
      "cost": "$350",
      "taxable": "0011",
      "qty": "25",
      "name":"Fountain",
    },

    ]



    // console.log(this.collection)

  }

  estimateView() {
    this.estimate = true;
    this.unbill = false;
    this.allSales = false;
    this.overDue = false;
    this.openInvoice = false;
    this.paid = false;
  }

  unbilledView() {
    this.unbill = true;
    this.estimate = false;
    this.allSales = false;
    this.overDue = false;
    this.openInvoice = false;
    this.paid = false;
  }

  overdueView() {
    this.overDue = true;
    this.unbill = false;
    this.estimate = false;
    this.allSales = false;
    this.openInvoice = false;
    this.paid = false;
  }
  openinvoiceView() {
    this.openInvoice = true;
    this.unbill = false;
    this.estimate = false;
    this.allSales = false;
    this.overDue = false;
    this.paid = false;
  }
  paidView() {
    this.paid = true;
    this.unbill = false;
    this.estimate = false;
    this.allSales = false;
    this.overDue = false;
    this.openInvoice = false;

  }
  backtoSales() {
    this.allSales = true;
    this.paid = false;
    this.unbill = false;
    this.estimate = false;
    this.overDue = false;
    this.openInvoice = false;
  }

  // Sorting
  setOrder(value: string) {
    console.log(value)
    if (this.order === value) {
      this.reverse = !this.reverse;
    }

    this.order = value;
  }
  // Sorting


  // Scrollbar
  public onScrollEvent(event: any): void {

  }
  // Scrollbar
}
