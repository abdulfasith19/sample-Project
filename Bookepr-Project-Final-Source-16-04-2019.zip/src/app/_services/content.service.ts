import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { HttpService } from '../_services/http.service';
import { UtilityService } from '../_services/utility.service';
import { Sort, Page } from '../_models';

@Injectable()
export class ContentService {

    constructor(
        private httpService: HttpService,
        private utilityService: UtilityService) { }
    

    faqList(){
        let url = '/faq/list';  
        return this.httpService.get(url); 
    }

}
