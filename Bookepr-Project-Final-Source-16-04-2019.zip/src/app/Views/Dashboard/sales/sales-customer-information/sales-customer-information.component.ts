import { Component, OnInit } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';

const URL = 'https://evening-anchorage-3159.herokuapp.com/api/';
@Component({
  selector: 'app-sales-customer-information',
  templateUrl: './sales-customer-information.component.html',
  styleUrls: ['./sales-customer-information.component.scss']
})
export class SalesCustomerInformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  public uploader:FileUploader = new FileUploader({url: URL});
  public hasBaseDropZoneOver:boolean = false;
  public hasAnotherDropZoneOver:boolean = false;
 
  public fileOverBase(e:any):void {
    this.hasBaseDropZoneOver = e;
  }
 
  public fileOverAnother(e:any):void {
    this.hasAnotherDropZoneOver = e;
  }

  datwrty(){
    console.log(this.uploader)
  }
}
