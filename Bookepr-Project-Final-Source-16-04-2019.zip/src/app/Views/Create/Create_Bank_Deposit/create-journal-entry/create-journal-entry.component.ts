import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';

@Component({
  selector: 'app-create-journal-entry',
  templateUrl: './create-journal-entry.component.html',
  styleUrls: ['./create-journal-entry.component.scss']
})
export class CreateJournalEntryComponent implements OnInit {
  collection:any;
  p: number = 1;
 //collection: any[]; 
 order: string;
 reverse: boolean = false;

 sortedCollection: any[];

 constructor(private orderPipe: OrderPipe){ }

 ngOnInit() {
   this.collection =[{
     
      
       "sno":'01',
       "Account":"Uncategorized Asset",
       "Debit":"$12.00",
       "Credit":"$12.00",
       "Description":"Lorem Ipsum Is a Dummy Text",
       "Name":"Cools Cars"
     
     },
   {
   
     "sno":'02',
     "Account":"Uncategorized Asset",
     "Debit":"$12.00",
     "Credit":"$12.00",
     "Description":"Lorem Ipsum Is a Dummy Text",
     "Name":"Cools Cars"
    
   },
   {
   
     "sno":'03',
     "Account":"Uncategorized Asset",
     "Debit":"$12.00",
     "Credit":"$12.00",
     "Description":"Lorem Ipsum Is a Dummy Text",
     "Name":"Cools Cars"
  
   },
   {
   
     "sno":'04',
     "Account":"Uncategorized Asset",
     "Debit":"$12.00",
     "Credit":"$12.00",
     "Description":"Lorem Ipsum Is a Dummy Text",
     "Name":"Cools Cars"
  
   }
    
 ]

   console.log(this.collection)
   
 }

 setOrder(value: string) {
   console.log(value)
   if (this.order === value) {
     this.reverse = !this.reverse;
   }

   this.order = value;
 }



}
 
