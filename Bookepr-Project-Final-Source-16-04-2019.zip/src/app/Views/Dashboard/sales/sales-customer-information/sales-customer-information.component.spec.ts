import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesCustomerInformationComponent } from './sales-customer-information.component';

describe('SalesCustomerInformationComponent', () => {
  let component: SalesCustomerInformationComponent;
  let fixture: ComponentFixture<SalesCustomerInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SalesCustomerInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SalesCustomerInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
