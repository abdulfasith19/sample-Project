import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MDBBootstrapModule } from 'angular-bootstrap-md';

import { CreateInvoiceComponent } from './Create_Customer/create-invoice/create-invoice.component';
import { CreateReceiveComponent } from './Create_Customer/create-receive/create-receive.component';
import { CreateEstimateComponent } from './Create_Customer/create-estimate/create-estimate.component';
import { CreateSalesReceiptComponent } from './Create_Customer/create-sales-receipt/create-sales-receipt.component';
import { CreateDelayedCreditComponent } from './Create_Customer/create-delayed-credit/create-delayed-credit.component';

import { CreateExpenseComponent } from './Vendors/create-expense/create-expense.component';
import { CreateCheckComponent } from './Vendors/create-check/create-check.component';
import { CreateBillsComponent } from './Vendors/create-bills/create-bills.component';
import { CreatePayBillsComponent } from './Vendors/create-pay-bills/create-pay-bills.component';
import { CreatePurchaseOrderComponent } from './Vendors/create-purchase-order/create-purchase-order.component';

import { CreateSingleTimeActivityComponent } from './Employees/create-single-time-activity/create-single-time-activity.component';
import { CreateWeeklyTimesheetComponent } from './Employees/create-weekly-timesheet/create-weekly-timesheet.component';

import { CreateBankDepositComponent } from './Create_Bank_Deposit/create-bank-deposit/create-bank-deposit.component';
import { CreateTransferComponent } from './Create_Bank_Deposit/create-transfer/create-transfer.component';
import { CreateJournalEntryComponent } from './Create_Bank_Deposit/create-journal-entry/create-journal-entry.component';
import { CreateStatementsComponent } from './Create_Bank_Deposit/create-statements/create-statements.component';
import { CreateInventyQtyAdjustmentComponent } from './Create_Bank_Deposit/create-inventy-qty-adjustment/create-inventy-qty-adjustment.component';

import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';
import { NgxPaginationModule } from 'ngx-pagination';
import { OrderModule } from 'ngx-order-pipe';
import { TabsModule } from 'ngx-bootstrap/tabs';




@NgModule({
  declarations: [
    CreateInvoiceComponent,
    CreateReceiveComponent,
    CreateEstimateComponent,
    CreateSalesReceiptComponent,
    CreateDelayedCreditComponent,
    CreateExpenseComponent,
    CreateCheckComponent,
    CreateBillsComponent,
    CreatePayBillsComponent,
    CreatePurchaseOrderComponent,
    CreateSingleTimeActivityComponent,
    CreateWeeklyTimesheetComponent,
    CreateBankDepositComponent,
    CreateTransferComponent,
    CreateJournalEntryComponent,
    CreateStatementsComponent,
    CreateInventyQtyAdjustmentComponent
  ],
        
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    NgxPaginationModule,
    NgxMaterialTimepickerModule,
    OrderModule,
    BsDatepickerModule.forRoot(),
    MDBBootstrapModule.forRoot(),
    TabsModule.forRoot()
  ],
  schemas: [ NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA ]
})
export class CreateModule { }
