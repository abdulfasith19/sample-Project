export class Sort {
    dir: string = null;
    prop: string = null;    
}