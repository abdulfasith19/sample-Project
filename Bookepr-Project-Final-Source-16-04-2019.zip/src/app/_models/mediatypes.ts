export class MediaTypes {
	media_type_id: number;
	media_type_name: string;
	reated_at: string;
	updated_at: string;
	created_by: number;
	updated_by: number;
}