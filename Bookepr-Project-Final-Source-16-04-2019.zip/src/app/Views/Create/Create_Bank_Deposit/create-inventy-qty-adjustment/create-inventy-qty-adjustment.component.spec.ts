import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateInventyQtyAdjustmentComponent } from './create-inventy-qty-adjustment.component';

describe('CreateInventyQtyAdjustmentComponent', () => {
  let component: CreateInventyQtyAdjustmentComponent;
  let fixture: ComponentFixture<CreateInventyQtyAdjustmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateInventyQtyAdjustmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateInventyQtyAdjustmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
