import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-rule',
  templateUrl: './new-rule.component.html',
  styleUrls: ['./new-rule.component.scss']
})
export class NewRuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
