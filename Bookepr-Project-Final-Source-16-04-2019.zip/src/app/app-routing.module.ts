import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Dashboard
import { DashboardComponent } from './Views/Dashboard/dashboard/dashboard.component';
import { BankingComponent } from './Views/Dashboard/banking/banking.component';
import { SalesComponent } from './Views/Dashboard/sales/sales.component';
import { ExpensesComponent } from './Views/Dashboard/expenses/expenses.component';
import { ReportsComponent } from './Views/Dashboard/reports/reports.component';
import { TaxesComponent } from './Views/Dashboard/taxes/taxes.component';
import { AccountingComponent } from './Views/Dashboard/accounting/accounting.component';
import { MyaccountantComponent } from './Views/Dashboard/myaccountant/myaccountant.component';

import { TaxesViewComponent } from './Views/Dashboard/taxes/taxes-view/taxes-view.component';
import { TaxesCenterComponent } from './Views/Dashboard/taxes/taxes-center/taxes-center.component';

import { VendorsComponent } from './Views/Dashboard/expenses/vendors/vendors.component';
import { VendorsInformationComponent } from './Views/Dashboard/expenses/vendors-information/vendors-information.component';
  
import { NewRuleComponent } from './Views/Dashboard/banking/new-rule/new-rule.component';
import { ConnectAccountComponent } from './Views/Dashboard/banking/connect-account/connect-account.component';

import { SalesCustomerComponent } from './Views/Dashboard/sales/sales-customer/sales-customer.component';
import { SalesCustomerInformationComponent } from './Views/Dashboard/sales/sales-customer-information/sales-customer-information.component';
import { ProductsCategoryComponent } from './Views/Dashboard/sales/products-category/products-category.component';
import { ProductsAndServicesTypesComponent } from './Views/Dashboard/sales/products-and-services-types/products-and-services-types.component';

import { ReconcileSummaryComponent } from './Views/Dashboard/accounting/reconcile-summary/reconcile-summary.component';
import { ReconcileHistoryComponent } from './Views/Dashboard/accounting/reconcile-history/reconcile-history.component';
import { ReconcileCheckingComponent } from './Views/Dashboard/accounting/reconcile-checking/reconcile-checking.component';
import { BankRegisterComponent } from './Views/Dashboard/accounting/bank-register/bank-register.component';

//Create

import { CreateInvoiceComponent } from './Views/Create/Create_Customer/create-invoice/create-invoice.component';
import { CreateReceiveComponent } from './Views/Create/Create_Customer/create-receive/create-receive.component';
import { CreateEstimateComponent } from './Views/Create/Create_Customer/create-estimate/create-estimate.component';
import { CreateSalesReceiptComponent } from './Views/Create/Create_Customer/create-sales-receipt/create-sales-receipt.component';
import { CreateDelayedCreditComponent } from './Views/Create/Create_Customer/create-delayed-credit/create-delayed-credit.component';

import { CreateExpenseComponent } from './Views/Create/Vendors/create-expense/create-expense.component';
import { CreateCheckComponent } from './Views/Create/Vendors/create-check/create-check.component';
import { CreateBillsComponent } from './Views/Create/Vendors/create-bills/create-bills.component';
import { CreatePayBillsComponent } from './Views/Create/Vendors/create-pay-bills/create-pay-bills.component';
import { CreatePurchaseOrderComponent } from './Views/Create/Vendors/create-purchase-order/create-purchase-order.component';

import { CreateSingleTimeActivityComponent } from './Views/Create/Employees/create-single-time-activity/create-single-time-activity.component';
import { CreateWeeklyTimesheetComponent } from './Views/Create/Employees/create-weekly-timesheet/create-weekly-timesheet.component';

import { CreateBankDepositComponent } from './Views/Create/Create_Bank_Deposit/create-bank-deposit/create-bank-deposit.component';
import { CreateTransferComponent } from './Views/Create/Create_Bank_Deposit/create-transfer/create-transfer.component';
import { CreateJournalEntryComponent } from './Views/Create/Create_Bank_Deposit/create-journal-entry/create-journal-entry.component';
import { CreateStatementsComponent } from './Views/Create/Create_Bank_Deposit/create-statements/create-statements.component';
import { CreateInventyQtyAdjustmentComponent } from './Views/Create/Create_Bank_Deposit/create-inventy-qty-adjustment/create-inventy-qty-adjustment.component';

//Profile

import { UserProfileComponent } from './Views/Profile/user-profile/user-profile.component';
import { UserFeedbacksComponent } from './Views/Profile/user-feedbacks/user-feedbacks.component';
import { PrivacyComponent } from './Views/Profile/privacy/privacy.component';
import { FaqComponent } from './Views/Profile/faq/faq.component';

//Settings

import { AllListsComponent } from './Views/Settings/Lists/all-lists/all-lists.component';
import { ListsTermsComponent } from './Views/Settings/Lists/lists-terms/lists-terms.component';
import { ListsPaymentComponent } from './Views/Settings/Lists/lists-payment/lists-payment.component';
import { AttachmentListComponent } from './Views/Settings/Lists/attachment-list/attachment-list.component';
import { RecurringTransactionsViewComponent } from './Views/Settings/Lists/recurring-transactions-view/recurring-transactions-view.component';
import { RecurringEditComponent } from './Views/Settings/Lists/recurring-edit/recurring-edit.component';

import { ImportDataComponent } from './Views/Settings/Tools/Import/import-data/import-data.component';
import { ImportCustomersComponent } from './Views/Settings/Tools/Import/import-customers/import-customers.component';

import { AccountSettingsComponent } from './Views/Settings/Your Company/Account-Settings/account-settings/account-settings.component';

import { CustomFormListComponent } from './Views/Settings/Your Company/Custom-form/custom-form-list/custom-form-list.component';
import { CustomFormEditComponent } from './Views/Settings/Your Company/Custom-form/custom-form-edit/custom-form-edit.component';

import { ManageUsersComponent } from './Views/Settings/Your Company/Manage-Users/manage-users/manage-users.component';
import { AddUsersComponent } from './Views/Settings/Your Company/Manage-Users/add-users/add-users.component';

import { ExportDataComponent } from './Views/Settings/Tools/export-data/export-data.component';
import { AuditComponent } from './Views/Settings/Tools/audit/audit.component';
import { AuditViewComponent } from './Views/Settings/Tools/audit-view/audit-view.component';

import { LoginComponent } from './login/login.component'

import { AuthGuard } from './_guards';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'Login' },
  //{ path: '', pathMatch: 'full', redirectTo: 'Dashboards/Dashboard' },
  { path: 'Dashboards', children:
    [
      { path: 'Dashboard', component: DashboardComponent },

      { path: 'Banking', component: BankingComponent },
      { path: 'NewRule', component: NewRuleComponent },
      { path: 'Connect-Account', component: ConnectAccountComponent },

      { path: 'Sales', component: SalesComponent },
      { path: 'Sales-Customer', component: SalesCustomerComponent },
      { path: 'Sales-Customer-Information', component: SalesCustomerInformationComponent },
      { path: 'Products-Category', component: ProductsCategoryComponent },
      { path: 'Products-And-Services-Types', component: ProductsAndServicesTypesComponent },
     
      { path: 'Expenses', component: ExpensesComponent },
      { path: 'Vendors', component: VendorsComponent },
      { path: 'Vendors-Information', component: VendorsInformationComponent },

      { path: 'Reports', component: ReportsComponent },

      { path: 'Taxes', component: TaxesComponent },
      { path: 'Taxes-View', component: TaxesViewComponent },
      { path: 'Taxes-Center', component: TaxesCenterComponent },
      
      { path: 'Accounting', component: AccountingComponent },
      { path: 'Reconcile-Summary', component: ReconcileSummaryComponent },
      { path: 'Reconcile-History', component: ReconcileHistoryComponent },
      { path: 'Reconcile-Checking', component: ReconcileCheckingComponent },
      { path: 'Bank-Register', component: BankRegisterComponent },

      { path: 'MyAccountant', component: MyaccountantComponent }
    ]
  },
  { path: 'Create-Delayed', component: CreateDelayedCreditComponent },
  { path: 'Create-Sales-Receipt', component: CreateSalesReceiptComponent },
  { path: 'Create-Estimate', component: CreateEstimateComponent },
  { path: 'Create-Receive', component: CreateReceiveComponent },
  { path: 'Create-Invoice', component: CreateInvoiceComponent },

  { path: 'Create-Expense', component: CreateExpenseComponent },
  { path: 'Create-Check', component: CreateCheckComponent },
  { path: 'Create-Bills', component: CreateBillsComponent },
  { path: 'Create-PayBills', component: CreatePayBillsComponent },
  { path: 'Create-PurchaseOrder', component: CreatePurchaseOrderComponent },

  { path: 'Create-SingleTimeActivity', component: CreateSingleTimeActivityComponent },
  { path: 'Create-WeeklyTimesheet', component: CreateWeeklyTimesheetComponent },

  { path: 'Create-BankDeposit', component: CreateBankDepositComponent },
  { path: 'Create-Transfer', component: CreateTransferComponent },
  { path: 'Create-JournalEntry', component: CreateJournalEntryComponent },
  { path: 'Create-Statements', component: CreateStatementsComponent },
  { path: 'Create-InventyQtyAdjustment', component: CreateInventyQtyAdjustmentComponent },

  /*{ path: 'User-Profile', component: UserProfileComponent },*/
  { path: 'user/profile', component: UserProfileComponent },
  { path: 'User-Feedbacks', component: UserFeedbacksComponent ,canActivate: [AuthGuard]},
  { path: 'Privacy', component: PrivacyComponent },
  { path: 'Faq', component: FaqComponent },

  { path: 'All-Lists', component: AllListsComponent },
  { path: 'Attachment-List', component: AttachmentListComponent },
  { path: 'List-terms', component: ListsTermsComponent },
  { path: 'List-payment', component: ListsPaymentComponent },
  { path: 'Recurring-Transactions-View', component: RecurringTransactionsViewComponent },
  { path: 'Recurring-Edit', component: RecurringEditComponent },

  { path: 'Import-Data', component: ImportDataComponent },
  { path: 'Import-Customers', component: ImportCustomersComponent },
  
  { path: 'Account-Settings', component: AccountSettingsComponent },

  { path: 'Custom-Form-List', component: CustomFormListComponent },
  { path: 'Custom-Form-Edit', component: CustomFormEditComponent },

  { path: 'Manage-Users', component: ManageUsersComponent },
  { path: 'Add-Users', component: AddUsersComponent },

  { path: 'Export-Data', component: ExportDataComponent },
  { path: 'Audit', component: AuditComponent },
  { path: 'Audit-View', component: AuditViewComponent },

  { path: 'Login', component: LoginComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
