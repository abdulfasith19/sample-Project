import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-create-weekly-timesheet',
  templateUrl: './create-weekly-timesheet.component.html',
  styleUrls: ['./create-weekly-timesheet.component.scss']
})
export class CreateWeeklyTimesheetComponent implements OnInit {


 constructor( ){ }

  ngOnInit() {
  }

}
