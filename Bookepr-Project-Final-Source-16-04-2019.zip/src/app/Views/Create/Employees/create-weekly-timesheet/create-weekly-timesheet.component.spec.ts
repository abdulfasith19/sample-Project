import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateWeeklyTimesheetComponent } from './create-weekly-timesheet.component';

describe('CreateWeeklyTimesheetComponent', () => {
  let component: CreateWeeklyTimesheetComponent;
  let fixture: ComponentFixture<CreateWeeklyTimesheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateWeeklyTimesheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateWeeklyTimesheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
