import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';

@Component({
  selector: 'app-create-statements',
  templateUrl: './create-statements.component.html',
  styleUrls: ['./create-statements.component.scss']
})
export class CreateStatementsComponent implements OnInit {
 
  collection:any;
  p: number = 1;
 //collection: any[]; 
 order: string;
 reverse: boolean = false;

 sortedCollection: any[];
 constructor(private orderPipe: OrderPipe ) { 

 }
  
  ngOnInit() {
    this.collection =[{

      "recipient":'Bill Windsurf Shop',
      "email_addr":"Invoice # 1012(12/02/2019)",
      "balance":"532"
    },
  {
     
    "recipient":'Bill Windsurf Shop',
    "email_addr":"Invoice # 1012(12/02/2019)",
    "balance":"532"
  }, 
  {
     
    "recipient":'Bill Windsurf Shop',
    "email_addr":"Invoice # 1012(12/02/2019)",
    "balance":"532"
  },
  {
     
    "recipient":'Bill Windsurf Shop',
    "email_addr":"Invoice # 1012(12/02/2019)",
    "balance":"532"
  },
  {
     
    "recipient":'Bill Windsurf Shop',
    "email_addr":"Invoice # 1012(12/02/2019)",
    "balance":"532"
  },
  {
     
    "recipient":'Bill Windsurf Shop',
    "email_addr":"Invoice # 1012(12/02/2019)",
    "balance":"532"
  },
  {
     
    "recipient":'Bill Windsurf Shop',
    "email_addr":"Invoice # 1012(12/02/2019)",
    "balance":"532"
  },
  {
     
    "recipient":'Bill Windsurf Shop',
    "email_addr":"Invoice # 1012(12/02/2019)",
    "balance":"532"
  },
  {
     
    "recipient":'Bill Windsurf Shop',
    "email_addr":"Invoice # 1012(12/02/2019)",
    "balance":"532"
  },
   
]

  console.log(this.collection)
  
}

setOrder(value: string) {
  console.log(value)
  if (this.order === value) {
    this.reverse = !this.reverse;
  }

  this.order = value;
}



}
