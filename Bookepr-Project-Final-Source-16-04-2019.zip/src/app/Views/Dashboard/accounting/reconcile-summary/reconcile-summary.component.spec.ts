import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReconcileSummaryComponent } from './reconcile-summary.component';

describe('ReconcileSummaryComponent', () => {
  let component: ReconcileSummaryComponent;
  let fixture: ComponentFixture<ReconcileSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReconcileSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReconcileSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
