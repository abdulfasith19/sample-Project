export class Accesses {
    access_id: number;
    user_id: number;
    access_date: string;
}