export const environment = {
  production: true,
  http:'http://',
  https:'https://',
  api_url: "app.bookepr.test/api",
  version: require('../../package.json').version
};
