import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';
@Component({
  selector: 'app-recurring-transactions-view',
  templateUrl: './recurring-transactions-view.component.html',
  styleUrls: ['./recurring-transactions-view.component.scss']
})
export class RecurringTransactionsViewComponent implements OnInit {
  collection: any;
  p: number = 1;
  //collection: any[]; 
  order: string;
  reverse: boolean = false;
 
  sortedCollection: any[];
 
  constructor(private orderPipe: OrderPipe) {

  }

  ngOnInit() {
    this.collection = [{
      
      "temp_name":'Craig Carlson',
      "type": "Schedulded",
      "tnx_type": "Bill",
      "interval": "Every Month",
      "previous": "",
      "next": "02/15/2015",
      "Cust_vend": "Hall Properties",
      "amount": "$693.25"
    },
    {
      
      "temp_name":'Craig Carlson',
      "type": "Schedulded",
      "tnx_type": "Bill",
      "interval": "Every Month",
      "previous": "",
      "next": "02/15/2015",
      "Cust_vend": "Hall Properties",
      "amount": "$693.25"
    },
    {
      
      "temp_name":'Craig Carlson',
      "type": "Schedulded",
      "tnx_type": "Bill",
      "interval": "Every Month",
      "previous": "",
      "next": "02/15/2015",
      "Cust_vend": "Hall Properties",
      "amount": "$693.25"
    },
    {
      
      "temp_name":'Craig Carlson',
      "type": "Schedulded",
      "tnx_type": "Bill",
      "interval": "Every Month",
      "previous": "",
      "next": "02/15/2015",
      "Cust_vend": "Hall Properties",
      "amount": "$693.25"
    },
    {
      
      "temp_name":'Craig Carlson',
      "type": "Schedulded",
      "tnx_type": "Bill",
      "interval": "Every Month",
      "previous": "",
      "next": "02/15/2015",
      "Cust_vend": "Hall Properties",
      "amount": "$693.25"
    },
    {
      
      "temp_name":'Craig Carlson',
      "type": "Schedulded",
      "tnx_type": "Bill",
      "interval": "Every Month",
      "previous": "",
      "next": "02/15/2015",
      "Cust_vend": "Hall Properties",
      "amount": "$693.25"
    },
    {
      
      "temp_name":'Craig Carlson',
      "type": "Schedulded",
      "tnx_type": "Bill",
      "interval": "Every Month",
      "previous": "",
      "next": "02/15/2015",
      "Cust_vend": "Hall Properties",
      "amount": "$693.25"
    },
    {
      
      "temp_name":'Craig Carlson',
      "type": "Schedulded",
      "tnx_type": "Bill",
      "interval": "Every Month",
      "previous": "",
      "next": "02/15/2015",
      "Cust_vend": "Hall Properties",
      "amount": "$693.25"
    },
    {
      
      "temp_name":'Craig Carlson',
      "type": "Schedulded",
      "tnx_type": "Bill",
      "interval": "Every Month",
      "previous": "",
      "next": "02/15/2015",
      "Cust_vend": "Hall Properties",
      "amount": "$693.25"
    },

    {
      
      "temp_name":'Craig Carlson',
      "type": "Schedulded",
      "tnx_type": "Bill",
      "interval": "Every Month",
      "previous": "",
      "next": "02/15/2015",
      "Cust_vend": "Hall Properties",
      "amount": "$693.25"
    }

    ]
  }
    setOrder(value: string) {
      console.log(value)
      if (this.order === value) {
        this.reverse = !this.reverse;
      }
   
      this.order = value;
    }
   
   
   
   }
    
   
  