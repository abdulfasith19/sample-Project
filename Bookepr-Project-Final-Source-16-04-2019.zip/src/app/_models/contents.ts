export class Contents {

	content_id: number;
	content_name: string;
	file_mime_type: string;
	file_name: string;
	file_size: number;
	th_mime_type: string;
	th_name: string;
	th_size: number;
	copyright: number;
	private_content: number;
	availability_date: any;
	expiration_date: any;
	notes: string;
	reated_at: string;
	updated_at: string;
	created_by: number;
	updated_by: number;
}