import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-banking",
  templateUrl: "./banking.component.html",
  styleUrls: ["./banking.component.scss"]
})
export class BankingComponent implements OnInit {


  checkingView = true;
  savingView = false;
  mastercardView = false;

  // Sub Tabs
  forreviewtab = true;
  reviewedtab = false;
  exculdedtab = false;

  status1 = true;
  status2 = false;
  status3 = false;

  bankingAdd = true;
  bankingMatch = false;
  bankingTransfer = false;

  constructor() { }

  ngOnInit() { }

  // dashboard banking
  checking() {
    this.checkingView = true;
    this.savingView = false;
    this.mastercardView = false;
    this.savingEdit = false;
    this.mastercardEdit = false;
  }

  saving() {
    this.checkingView = false;
    this.savingView = true;
    this.mastercardView = false;
    this.checkingEdit = false;
    this.mastercardEdit = false;
  }

  mastercard() {
    this.checkingView = false;
    this.savingView = false;
    this.mastercardView = true;
    this.checkingEdit = false;
    this.savingEdit = false;
  }
  //edit
  checkingEdit = false;
  savingEdit = false;
  mastercardEdit = false;

  checkingOpen() {
    this.checkingEdit = true;
    this.savingEdit = false;
    this.mastercardEdit = false;
  }

  savingOpen() {
    this.checkingEdit = false;
    this.savingEdit = true;
    this.mastercardEdit = false;
  }

  mastercardsOpen() {
    this.mastercardEdit = true;
    this.checkingEdit = false;
    this.savingEdit = false;
  }

  checkingClose() {
    this.checkingEdit = false;
  }
  savingClose() {
    this.savingEdit = false;

  }
  mastercardsClose() {
    this.mastercardEdit = false;
  }


  // Sub Tabs
  reviewed() {
    this.forreviewtab = false;
    this.reviewedtab = true;
    this.exculdedtab = false;

    this.status2 = !this.status2;
    this.status1 = false;
    this.status3 = false;
  }
  forreview() {
    this.forreviewtab = true;
    this.reviewedtab = false;
    this.exculdedtab = false;

    this.status1 = !this.status1;
    this.status2 = false;
    this.status3 = false;
  }
  exculded() {
    this.forreviewtab = false;
    this.reviewedtab = false;
    this.exculdedtab = true;

    this.status3 = !this.status3;
    this.status1 = false;
    this.status2 = false;
  }

  //sub tab  radio
  bankingadd_view() {
    this.bankingAdd = true;
    this.bankingMatch = false;
    this.bankingTransfer = false;
  }
  bankingmatch_view() {
    this.bankingAdd = false;
    this.bankingMatch = true;
    this.bankingTransfer = false;
  }
  bankingtransfer_view() {
    this.bankingAdd = false;
    this.bankingMatch = false;
    this.bankingTransfer = true;
  }
}
