import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductsAndServicesTypesComponent } from './products-and-services-types.component';

describe('ProductsAndServicesTypesComponent', () => {
  let component: ProductsAndServicesTypesComponent;
  let fixture: ComponentFixture<ProductsAndServicesTypesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductsAndServicesTypesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsAndServicesTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
