import { Component, OnInit } from '@angular/core';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  less:boolean=true;

  constructor( private service : DataService) { }

  ngOnInit() {

    this.service.toggleSidebar.subscribe(() => {
      console.log("this.less") 
      this.less=!this.less;    
          }); 
  }

}
