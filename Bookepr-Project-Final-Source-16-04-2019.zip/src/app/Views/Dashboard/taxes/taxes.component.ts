import { Component, OnInit,ViewChild } from '@angular/core';
import {
  PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective
} from 'ngx-perfect-scrollbar';
@Component({
  selector: 'app-taxes',
  templateUrl: './taxes.component.html',
  styleUrls: ['./taxes.component.scss']
})
export class TaxesComponent implements OnInit {

  constructor() { }

 // Scrollbar
 public type: string = 'component';

 public disabled: boolean = false;

 public config: PerfectScrollbarConfigInterface = {};

 @ViewChild(PerfectScrollbarComponent) componentRef?: PerfectScrollbarComponent;
 @ViewChild(PerfectScrollbarDirective) directiveRef?: PerfectScrollbarDirective;

 // Scrollbar

  ngOnInit() {
  }

  // Scrollbar
  public scrollToXY(x: number, y: number): void {
    if (this.type === 'directive' && this.directiveRef) {
      this.directiveRef.scrollTo(x, y, 500);
    }  else if (this.type === 'component' && this.componentRef && this.componentRef.directiveRef) {
      this.componentRef.directiveRef.scrollTo(x, y, 500);
    }
  }
  // Scrollbar


   // Scrollbar
   public onScrollEvent(event: any): void {

  }
  // Scrollbar


}
