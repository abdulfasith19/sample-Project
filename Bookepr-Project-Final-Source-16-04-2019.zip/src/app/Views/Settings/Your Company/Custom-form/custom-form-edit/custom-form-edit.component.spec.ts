import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomFormEditComponent } from './custom-form-edit.component';

describe('CustomFormEditComponent', () => {
  let component: CustomFormEditComponent;
  let fixture: ComponentFixture<CustomFormEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomFormEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomFormEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
