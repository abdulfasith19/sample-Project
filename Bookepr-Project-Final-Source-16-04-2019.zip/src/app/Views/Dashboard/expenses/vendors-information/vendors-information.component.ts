import { Component, OnInit } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';

const URL = 'https://evening-anchorage-3159.herokuapp.com/api/';
@Component({
  selector: 'app-vendors-information',
  templateUrl: './vendors-information.component.html',
  styleUrls: ['./vendors-information.component.scss']
})
export class VendorsInformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  public uploader:FileUploader = new FileUploader({url: URL});
  public hasBaseDropZoneOver:boolean = false;
  public hasAnotherDropZoneOver:boolean = false;
 
  public fileOverBase(e:any):void {
    this.hasBaseDropZoneOver = e;
  }
 
  public fileOverAnother(e:any):void {
    this.hasAnotherDropZoneOver = e;
  }

  datwrty(){
    console.log(this.uploader)
  }
}
