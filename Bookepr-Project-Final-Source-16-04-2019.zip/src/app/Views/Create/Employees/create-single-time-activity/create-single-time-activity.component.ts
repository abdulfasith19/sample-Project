import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-single-time-activity',
  templateUrl: './create-single-time-activity.component.html',
  styleUrls: ['./create-single-time-activity.component.scss']
})
export class CreateSingleTimeActivityComponent implements OnInit {
  public show:boolean = false;
 
  constructor() { }

  ngOnInit() {
  }


  toggle(){
    this.show = !this.show;
  
    // CHANGE THE NAME OF THE BUTTON.
  }
}
