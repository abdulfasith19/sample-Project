import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DataService } from '../../services/data.service';
import { ActivatedRoute , Router } from '@angular/router';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss']
})
export class NavigationComponent implements OnInit {
  @ViewChild('sidenav') sidenav: ElementRef;

  less:boolean=true;

  clicked: boolean;
  // status: boolean = false;
  // status2: boolean = false;
  constructor( private service : DataService , private router : Router ) {
    this.clicked = this.clicked === undefined ? false : true;
  }

  ngOnInit() {

    this.service.toggleSidebar.subscribe(() => {
      console.log("this.less") 
      this.less=!this.less;    
          }); 
  }

  setClicked(val: boolean): void {
    this.clicked = val;
  }
//   clickLink1(){
//     this.status = !this.status;       
// }
// clickLink2(){
//   this.status2 = !this.status2;       
// }


// status: boolean = false;
menuclickEvent(){
    // this.status = !this.status;       
    this.service.toggleSidebar.emit();

}
logout(){
    this.router.navigate(['/Login']);
}

}
