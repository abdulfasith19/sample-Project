import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-piechart',
  templateUrl: './piechart.component.html',
  styleUrls: ['./piechart.component.scss']
})
export class PiechartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  public chartType: string = 'line';

  public chartDatasets: Array<any> = [
    { data: [0, 65, 45, 65, 35, 65, 0], label: 'THIS MONTH' }
  ];

  public chartLabels: Array<any> = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];

  public chartColors: Array<any> = [
    {
      backgroundColor: "rgba(255, 162, 167, 0.2)",
      borderColor: '#ffb767',
      borderWidth: 2,
      pointBorderColor: "#ff5b53",
      pointBackgroundColor: "#fff",
    }
  ];

  public chartOptions: any = {
    responsive: true
  };
  public chartClicked(e: any): void { }
  public chartHovered(e: any): void { }
}
