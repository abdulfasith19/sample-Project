import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doughnutchart',
  templateUrl: './doughnutchart.component.html',
  styleUrls: ['./doughnutchart.component.scss']
})
export class DoughnutchartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  public chartType: string = 'doughnut';

  public chartDatasets: Array<any> = [
    { data: [50, 50, 50], label: 'My First dataset' }
  ];

  public chartLabels: Array<any> = ['Open Invoices', 'Overdue Invoices', 'Paid Last 30days'];

  public chartColors: Array<any> = [
    {
      backgroundColor: ['#86acf3', '#46c9b8', '#fe8a96'],
      hoverBackgroundColor: ['#fe8a96', '#46c9b8', '#86acf3'],
      borderWidth: 2,
    }
  ];

  public chartOptions: any = {
    responsive: true
  };
  public chartClicked(e: any): void { }
  public chartHovered(e: any): void { }
}
