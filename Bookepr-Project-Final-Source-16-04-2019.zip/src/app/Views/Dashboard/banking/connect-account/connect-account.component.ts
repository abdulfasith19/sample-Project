import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-connect-account',
  templateUrl: './connect-account.component.html',
  styleUrls: ['./connect-account.component.scss']
})
export class ConnectAccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
