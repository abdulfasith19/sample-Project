import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';
import {
  PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective
} from 'ngx-perfect-scrollbar';
import { ViewChild } from '@angular/core';

@Component({
  selector: 'app-recurring-edit',
  templateUrl: './recurring-edit.component.html',
  styleUrls: ['./recurring-edit.component.scss']
})
export class RecurringEditComponent implements OnInit {

  // Table-Jason
  collection: any;
  items: any;
  customerlist: any;
  productservices: any;
  // estimation:any;
  // Table-Jason

  // Sorting
  order: string;
  reverse: boolean = false;


  allSales: boolean = true;
  estimate: boolean = false;
  unbill: boolean = false;
  overDue: boolean = false;
  openInvoice: boolean = false;
  paid: boolean = false;



  sortedCollection: any[];
  // Sorting

  // Scrollbar
  public type: string = 'component';

  public disabled: boolean = false;

  public config: PerfectScrollbarConfigInterface = {};

  @ViewChild(PerfectScrollbarComponent) componentRef?: PerfectScrollbarComponent;
  @ViewChild(PerfectScrollbarDirective) directiveRef?: PerfectScrollbarDirective;

  // Scrollbar

  constructor(private orderPipe: OrderPipe) {

  }

  // Scrollbar
  public scrollToXY(x: number, y: number): void {
    if (this.type === 'directive' && this.directiveRef) {
      this.directiveRef.scrollTo(x, y, 500);
    }  else if (this.type === 'component' && this.componentRef && this.componentRef.directiveRef) {
      this.componentRef.directiveRef.scrollTo(x, y, 500);
    }
  }
  // Scrollbar

  ngOnInit() {

    this.collection = [{
      "sno": "01",
      "Category": "Rent or Lease",
      "Description": 'Lorem Ipsum is a dummy text',
      "Amount": '900',
      "Billable": "12345",
      "Tax": "$1,010.00",
      "Customer": "Lorem Ipsum"
    },
    {
      "sno": "02",
      "Category": "Rent or Lease",
      "Description": 'Lorem Ipsum is a dummy text',
      "Amount": '900',
      "Billable": "12345",
      "Tax": "$1,010.00",
      "Customer": "Lorem Ipsum"
    },
    {
      "sno": "03",
      "Category": "Rent or Lease",
      "Description": 'Lorem Ipsum is a dummy text',
      "Amount": '900',
      "Billable": "12345",
      "Tax": "$1,010.00",
      "Customer": "Lorem Ipsum"
    },
    {
      "sno": "04",
      "Category": "Rent or Lease",
      "Description": 'Lorem Ipsum is a dummy text',
      "Amount": '900',
      "Billable": "12345",
      "Tax": "$1,010.00",
      "Customer": "Lorem Ipsum"
    },
    {
      "sno": "05",
      "Category": "Rent or Lease",
      "Description": 'Lorem Ipsum is a dummy text',
      "Amount": '900',
      "Billable": "12345",
      "Tax": "$1,010.00",
      "Customer": "Lorem Ipsum"
    },
    {
      "sno": "06",
      "Category": "Rent or Lease",
      "Description": 'Lorem Ipsum is a dummy text',
      "Amount": '900',
      "Billable": "12345",
      "Tax": "$1,010.00",
      "Customer": "Lorem Ipsum"
    },
    {
      "sno": "07",
      "Category": "Rent or Lease",
      "Description": 'Lorem Ipsum is a dummy text',
      "Amount": '900',
      "Billable": "12345",
      "Tax": "$1,010.00",
      "Customer": "Lorem Ipsum"
    },
    {
      "sno": "08",
      "Category": "Rent or Lease",
      "Description": 'Lorem Ipsum is a dummy text',
      "Amount": '900',
      "Billable": "12345",
      "Tax": "$1,010.00",
      "Customer": "Lorem Ipsum"
    },
    {
      "sno": "09",
      "Category": "Rent or Lease",
      "Description": 'Lorem Ipsum is a dummy text',
      "Amount": '900',
      "Billable": "12345",
      "Tax": "$1,010.00",
      "Customer": "Lorem Ipsum"
    },

    {
      "sno": "10",
      "Category": "Rent or Lease",
      "Description": 'Lorem Ipsum is a dummy text',
      "Amount": '900',
      "Billable": "12345",
      "Tax": "$1,010.00",
      "Customer": "Lorem Ipsum"
    },

    ]


    this.items = [{
      "sno": '01',
      "Product": 'Rent or Lease',
      "Description": 'Lorem Ipsum Is a Dummy Text',
      "Qty": "",
      "Rate": "",
      "Amount": "",
      "Billable" : "",
      "Tax": ""
    },
    {
      "sno": '02',
      "Product": 'Rent or Lease',
      "Description": 'Lorem Ipsum Is a Dummy Text',
      "Qty": "",
      "Rate": "",
      "Amount": "",
      "Billable" : "",
      "Tax": ""
    },
    {
      "sno": '03',
      "Product": 'Rent or Lease',
      "Description": 'Lorem Ipsum Is a Dummy Text',
      "Qty": "",
      "Rate": "",
      "Amount": "",
      "Billable" : "",
      "Tax": ""
    },
    {
      "sno": '04',
      "Product": 'Rent or Lease',
      "Description": 'Lorem Ipsum Is a Dummy Text',
      "Qty": "",
      "Rate": "",
      "Amount": "",
      "Billable" : "",
      "Tax": ""
    },
    {
      "sno": '05',
      "Product": 'Rent or Lease',
      "Description": 'Lorem Ipsum Is a Dummy Text',
      "Qty": "",
      "Rate": "",
      "Amount": "",
      "Billable" : "",
      "Tax": ""
    },
    {
      "sno": '06',
      "Product": 'Rent or Lease',
      "Description": 'Lorem Ipsum Is a Dummy Text',
      "Qty": "",
      "Rate": "",
      "Amount": "",
      "Billable" : "",
      "Tax": ""
    },
    {
      "sno": '07',
      "Product": 'Rent or Lease',
      "Description": 'Lorem Ipsum Is a Dummy Text',
      "Qty": "",
      "Rate": "",
      "Amount": "",
      "Billable" : "",
      "Tax": ""
    },
    {
      "sno": '08',
      "Product": 'Rent or Lease',
      "Description": 'Lorem Ipsum Is a Dummy Text',
      "Qty": "",
      "Rate": "",
      "Amount": "",
      "Billable" : "",
      "Tax": ""
    },
    {
      "sno": '09',
      "Product": 'Rent or Lease',
      "Description": 'Lorem Ipsum Is a Dummy Text',
      "Qty": "",
      "Rate": "",
      "Amount": "",
      "Billable" : "",
      "Tax": ""
    },

    {
      "sno": '10',
      "Product": 'Rent or Lease',
      "Description": 'Lorem Ipsum Is a Dummy Text',
      "Qty": "",
      "Rate": "",
      "Amount": "",
      "Billable" : "",
      "Tax": ""
    },

    ]


    





    // console.log(this.collection)

  }



  unbilledView() {
    this.unbill = true;
    this.estimate = false;
    this.allSales = false;
    this.overDue = false;
    this.openInvoice = false;
    this.paid = false;
  }

  overdueView() {
    this.overDue = true;
    this.unbill = false;
    this.estimate = false;
    this.allSales = false;
    this.openInvoice = false;
    this.paid = false;
  }
  openinvoiceView() {
    this.openInvoice = true;
    this.unbill = false;
    this.estimate = false;
    this.allSales = false;
    this.overDue = false;
    this.paid = false;
  }
  paidView() {
    this.paid = true;
    this.unbill = false;
    this.estimate = false;
    this.allSales = false;
    this.overDue = false;
    this.openInvoice = false;

  }
  backtoSales() {
    this.allSales = true;
    this.paid = false;
    this.unbill = false;
    this.estimate = false;
    this.overDue = false;
    this.openInvoice = false;
  }

  // Sorting
  setOrder(value: string) {
    console.log(value)
    if (this.order === value) {
      this.reverse = !this.reverse;
    }

    this.order = value;
  }
  // Sorting


  // Scrollbar
  public onScrollEvent(event: any): void {

  }
  // Scrollbar
}

