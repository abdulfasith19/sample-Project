import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';

@Component({
  selector: 'app-create-receive',
  templateUrl: './create-receive.component.html',
  styleUrls: ['./create-receive.component.scss']
})
export class CreateReceiveComponent implements OnInit {
  collection:any;
  p: number = 1;
 //collection: any[]; 
 order: string;
 reverse: boolean = false;

 sortedCollection: any[];
 constructor(private orderPipe: OrderPipe ) { 

 }
  
  ngOnInit() {
    this.collection =[{

      "sno":'01',
      "description":"Invoice # 1012(12/02/2019)",
      "due_date":"(13/02/2019)",
      "original_amt":"532",
      "open_balance":"532",
      "payment":"532"
    },
  {
      "sno":'02',
      "description":"Invoice # 1013(12/02/2019)",
      "due_date":"(13/02/2019)",
      "original_amt":"532",
      "open_balance":"532",
      "payment":""
  }
   
]

  console.log(this.collection)
  
}

setOrder(value: string) {
  console.log(value)
  if (this.order === value) {
    this.reverse = !this.reverse;
  }

  this.order = value;
}



}


