import { Component, OnInit, Input, Renderer, ViewChild, ElementRef } from '@angular/core';
import { ProfileService } from 'src/app/services/profile.service';
import { UtilityService } from '../../../_services';
import { UserProfileService } from 'src/app/_services/user-profile.service';
import { Profile } from 'src/app/_models/profile';
import {FormGroup, FormControl,FormBuilder,Validators } from '@angular/forms';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss'],
  providers: [ProfileService, UtilityService,UserProfileService]
})

export class UserProfileComponent implements OnInit {

  profileForm : FormGroup;

  //profileForm = new FormControl('');

  // profileForm = new FormGroup({
  //   email: new FormControl(''),
  //   mobile: new FormControl(''),
  // });

  clickMessage = '';
  submitted = false;
  user: Profile ;

  public show:boolean = false;
  public mybutton:any = 'Show';

  constructor(private profileService : ProfileService ,private fb: FormBuilder,private renderer:Renderer) {}
  @ViewChild('fileInput') fileInput:ElementRef;

  ngOnInit() {
    this.profileService.getContact().subscribe(res=> {
      this.user = res;
      // alert(this.user.contact_number)
    });
  }

  submitUser(form){
    var data = {
      "user_id":form.value.user_id
      //"password":form.value.password
    }
    this.profileService.sendUser(data);
  }

  getfile(){
    let event = new MouseEvent('click', {bubbles: true});
    this.renderer.invokeElementMethod(
      this.fileInput.nativeElement, 'dispatchEvent', [event]);
  }

  submitEmail(form){
    // alert(form.value.email_address);
    // alert(JSON.stringify(form.value))
    var data = {
      // "email":'priya1@gmail.com'
      "email":form.value.email_address
    }
    this.profileService.sendEmail(data)
    // .subscribe(res=>{
    //   alert("profile send email data===>"+res);
    // }, err=>{
    //   alert("proifle error send email===>"+err)
    // })
  }

  submitMobile(form){
    var data = {
      "mobile":form.value.contact_number
    }
    this.profileService.sendMobile(data);
  }

  submitName(form){
    var data = {
      "first_name":form.value.first_name,
      "last_name":form.value.last_name
    }
    this.profileService.sendName(data);
  }

  toggle() {
    this.show = !this.show;

    // CHANGE THE NAME OF THE BUTTON.
    if(this.show){
      this.mybutton= "Hide";
    } else {
      this.mybutton= "Show";
    }
  }

  changePassword(form){
    alert(form.value.old_password);
    var data = {
      "old_password":form.value.old_password,
      "password":form.value.new_password,
      "confirm_password":form.value.confirm_password
    }
    this.profileService.changePassword(data);
  }


}
