import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-and-services-types',
  templateUrl: './products-and-services-types.component.html',
  styleUrls: ['./products-and-services-types.component.scss']
})
export class ProductsAndServicesTypesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
