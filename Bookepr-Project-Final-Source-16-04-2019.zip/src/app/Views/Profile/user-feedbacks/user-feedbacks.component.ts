import { Component, OnInit,Renderer,ViewChild ,ElementRef} from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { ProfileService } from 'src/app/services/profile.service';
import { UtilityService } from '../../../_services';
import { UserProfileService } from 'src/app/_services/user-profile.service';
import { Feedback } from 'src/app/_models/feedback';


@Component({
  selector: 'app-user-feedbacks',
  templateUrl: './user-feedbacks.component.html',
  styleUrls: ['./user-feedbacks.component.scss'],
  providers: [ProfileService, UtilityService,UserProfileService]
})
export class UserFeedbacksComponent implements OnInit {

  FeedbackForm: FormGroup;
  model: Feedback; 
  submittedModel: Feedback;
  comment: string;
  feedback: Feedback;
  submitted: boolean = false;

  constructor(private renderer:Renderer,
              private formBuilder: FormBuilder,
              private profileService : ProfileService) { }

  @ViewChild('fileInput') fileInput:ElementRef;

  getfile(){
    let event = new MouseEvent('click', {bubbles: true});
    this.renderer.invokeElementMethod(
        this.fileInput.nativeElement, 'dispatchEvent', [event]);
  }


  ngOnInit() {
  this.comment = "";
  this.FeedbackForm = this.formBuilder.group({
        comment: [this.comment, Validators.required]
        
      });
  this.profileService.getContact().subscribe(res=> {
    this.feedback = res;
    //  alert(this.feedback.comment)
  });

  }
  
  onSubmit(form) {
    console.log(form.value.comment);
    var data = {
      "comment":form.value.comment
    }
    this.profileService.sendFeedback(data);
  }

 
  // onSubmit(feedbackForm: NgForm) {
  //   console.log(feedbackForm);
  //   this.insertRecord(feedbackForm);
  // }

  // insertRecord(feedbackForm: NgForm){ 

  // }

}
