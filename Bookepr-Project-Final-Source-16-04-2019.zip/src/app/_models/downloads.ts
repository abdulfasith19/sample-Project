export class Downloads {

    download_id: number;
    user_id: number;
    content_id: number;
    download_date: string;
}