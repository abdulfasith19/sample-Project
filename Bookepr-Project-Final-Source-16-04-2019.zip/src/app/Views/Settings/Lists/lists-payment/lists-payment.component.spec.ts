import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListsPaymentComponent } from './lists-payment.component';

describe('ListsPaymentComponent', () => {
  let component: ListsPaymentComponent;
  let fixture: ComponentFixture<ListsPaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListsPaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListsPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
