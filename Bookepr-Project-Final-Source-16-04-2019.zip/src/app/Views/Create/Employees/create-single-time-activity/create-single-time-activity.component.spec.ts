import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateSingleTimeActivityComponent } from './create-single-time-activity.component';

describe('CreateSingleTimeActivityComponent', () => {
  let component: CreateSingleTimeActivityComponent;
  let fixture: ComponentFixture<CreateSingleTimeActivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateSingleTimeActivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateSingleTimeActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
