import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-settings',
  templateUrl: './account-settings.component.html',
  styleUrls: ['./account-settings.component.scss']
})
export class AccountSettingsComponent implements OnInit {
  public show:boolean = true;
  constructor() { }

  ngOnInit() {
  }
toggle(){
    this.show = !this.show;
  
    // CHANGE THE NAME OF THE BUTTON.
  }
}
