import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecurringEditComponent } from './recurring-edit.component';

describe('RecurringEditComponent', () => {
  let component: RecurringEditComponent;
  let fixture: ComponentFixture<RecurringEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecurringEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecurringEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
