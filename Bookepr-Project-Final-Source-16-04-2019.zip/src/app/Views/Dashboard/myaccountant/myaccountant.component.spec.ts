import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyaccountantComponent } from './myaccountant.component';

describe('MyaccountantComponent', () => {
  let component: MyaccountantComponent;
  let fixture: ComponentFixture<MyaccountantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyaccountantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyaccountantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
