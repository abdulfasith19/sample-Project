import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';


@Component({
  selector: 'app-create-inventy-qty-adjustment',
  templateUrl: './create-inventy-qty-adjustment.component.html',
  styleUrls: ['./create-inventy-qty-adjustment.component.scss']
})
export class CreateInventyQtyAdjustmentComponent implements OnInit {
  collection:any;
  p: number = 1;
 //collection: any[]; 
 order: string;
 reverse: boolean = false;

 sortedCollection: any[];

 constructor(private orderPipe: OrderPipe ){ }

 ngOnInit() {
   this.collection =[{
     
      
       "sno":'01',
       "Product":"Landscaping (Gardening)",
       "Description":"Lorem Is a dummy text",
       "Qty_hand":"5",
       "New_qty":"600",
       "Change_qty":"3000"
     
     },
   {
   
     "sno":'02',
     "Product":"Landscaping (Gardening)",
     "Description":"Lorem Is a dummy text",
     "Qty_hand":"5",
     "New_qty":"300",
     "Change_qty":"1500"
    
   }
    
 ]

   console.log(this.collection)
   
 }

 setOrder(value: string) {
   console.log(value)
   if (this.order === value) {
     this.reverse = !this.reverse;
   }

   this.order = value;
 }



}
 


