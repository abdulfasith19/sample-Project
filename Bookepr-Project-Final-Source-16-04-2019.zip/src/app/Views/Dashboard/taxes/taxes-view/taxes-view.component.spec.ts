import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxesViewComponent } from './taxes-view.component';

describe('TaxesViewComponent', () => {
  let component: TaxesViewComponent;
  let fixture: ComponentFixture<TaxesViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaxesViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxesViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
