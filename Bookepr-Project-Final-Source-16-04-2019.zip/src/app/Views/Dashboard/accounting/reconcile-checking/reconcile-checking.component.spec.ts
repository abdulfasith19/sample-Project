import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReconcileCheckingComponent } from './reconcile-checking.component';

describe('ReconcileCheckingComponent', () => {
  let component: ReconcileCheckingComponent;
  let fixture: ComponentFixture<ReconcileCheckingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReconcileCheckingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReconcileCheckingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
