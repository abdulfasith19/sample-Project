import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';


@Component({
  selector: 'app-create-delayed-credit',
  templateUrl: './create-delayed-credit.component.html',
  styleUrls: ['./create-delayed-credit.component.scss']
})
export class CreateDelayedCreditComponent implements OnInit {
  collection:any;
   p: number = 1;
  //collection: any[]; 
  order: string;
  reverse: boolean = false;

  sortedCollection: any[];

 constructor(private orderPipe: OrderPipe){ }

  ngOnInit() {
    this.collection =[{
      
       
        "sno":'01',
        "Product":"Landscaping (Gardening)",
        "Description":"Lorem Is a dummy text",
        "Qty":"5",
        "Rate":"600",
        "Amount":"3000"
      
      },
    {
    
      "sno":'02',
      "Product":"Landscaping (Gardening)",
      "Description":"Lorem Is a dummy text",
      "Qty":"5",
      "Rate":"300",
      "Amount":"1500"
     
    }
     
  ]

    console.log(this.collection)
    
  }

  setOrder(value: string) {
    console.log(value)
    if (this.order === value) {
      this.reverse = !this.reverse;
    }

    this.order = value;
  }


 
}
  


