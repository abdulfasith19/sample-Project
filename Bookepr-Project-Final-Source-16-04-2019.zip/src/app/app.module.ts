
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';



// main layout
import { NavigationModule } from './main-layout/navigation/navigation.module';
import { FooterComponent } from './main-layout/footer/footer.component';
import { ViewModule } from './Views/view.module';
import { CreateModule } from './Views/Create/create.module';
import { SettingsModule } from './Views/Settings/settings.module';
import { LoginComponent } from './login/login.component';


//Thirdparty 
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ToastrModule, ToastContainerModule } from 'ngx-toastr';
import { NgProgressModule } from '@ngx-progressbar/core';
import { NgProgressHttpModule } from '@ngx-progressbar/http';

//Authservice and Gurd
import { AuthenticationService, HttpService, UtilityService,ContentService } from './_services';
import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { WINDOW_PROVIDERS } from './_providers/window.provider';
import { AuthGuard } from './_guards';
import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';



@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    LoginComponent
  
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    NavigationModule,
    ViewModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    NgxMaterialTimepickerModule,
    MDBBootstrapModule.forRoot(),
    ToastrModule.forRoot({
      timeOut: 5000,
      positionClass: 'toast-top-right',
      preventDuplicates: true,
    }),
    AppRoutingModule,
    HttpClientModule,
    NgProgressModule,
    NgProgressModule,
    NgProgressHttpModule,
    CreateModule,
    SettingsModule
    
    
  ],
  providers: [
    AuthGuard,    
    AuthenticationService,    
    UtilityService,
    ContentService,
    HttpService,
    WINDOW_PROVIDERS,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }
  ],
  schemas: [ NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA ],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}


