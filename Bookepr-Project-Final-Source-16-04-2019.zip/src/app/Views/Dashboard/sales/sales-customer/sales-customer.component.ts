import { Component, OnInit } from '@angular/core';
import { OrderPipe } from 'ngx-order-pipe';
import { PerfectScrollbarConfigInterface,
  PerfectScrollbarComponent, PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { ViewChild } from '@angular/core';

@Component({
  selector: 'app-sales-customer',
  templateUrl: './sales-customer.component.html',
  styleUrls: ['./sales-customer.component.scss']
})
export class SalesCustomerComponent implements OnInit {


// Table-Jason
collection:any;
// Table-Jason

// Sorting
order: string;
reverse: boolean = false;


sortedCollection: any[];
// Sorting

// Scrollbar
public type: string = 'component';

public disabled: boolean = false;

public config: PerfectScrollbarConfigInterface = {};

@ViewChild(PerfectScrollbarComponent) componentRef?: PerfectScrollbarComponent;
@ViewChild(PerfectScrollbarDirective) directiveRef?: PerfectScrollbarDirective;

// Scrollbar

constructor(private orderPipe: OrderPipe  ) { 

}

// Scrollbar
public scrollToXY(x: number, y: number): void {
  if (this.type === 'directive' && this.directiveRef) {
    this.directiveRef.scrollTo(x, y, 500);
  } else if (this.type === 'component' && this.componentRef && this.componentRef.directiveRef) {
    this.componentRef.directiveRef.scrollTo(x, y, 500);
  }
}
// Scrollbar

ngOnInit() {

  this.collection =[{
    "checkbox":'01',
    "sno":'01',
    "date":'(12/02/2019)',
    "type":"1020",
    "no":"Invoice",
    "duedate":"02/13/2019",
    "balance":"$314.28",
    "total":"$78.20",
    "status":"open"
  },
  {
    "checkbox":'02',
    "sno":'02',
    "date":'(13/02/2019)',
    "type":"1021",
    "no":"Invoice",
    "duedate":"03/13/2019",
    "balance":"$314.28",
    "total":"$78.20",
    "status":"closed"
},
  {
    "checkbox":'03',
    "sno":'03',
    "date":'(14/02/2019)',
    "type":"1022",
    "no":"Invoice",
    "duedate":"04/13/2019",
    "balance":"$314.28",
    "total":"$78.20",
    "status":"paid"
  },
    {
      "checkbox":'04',
      "sno":'04',
      "date":'(15/02/2019)',
      "type":"1023",
      "no":"Invoice",
      "duedate":"05/13/2019",
      "balance":"$314.28",
      "total":"$78.20",
      "status":"overdue"
    },
      {
        "checkbox":'06',
        "sno":'05',
        "date":'(16/02/2019)',
        "type":"1024",
        "no":"Invoice",
        "duedate":"06/13/2019",
        "balance":"$314.28",
        "total":"$78.20",
        "status":"open"
      },
      {
        "checkbox":'07',
        "sno":'06',
        "date":'(17/02/2019)',
        "type":"1025",
        "no":"Invoice",
        "duedate":"07/13/2019",
        "balance":"$314.28",
        "total":"$78.20",
        "status":"open"
      },
      {
        "checkbox":'08',
        "sno":'07',
        "date":'(18/02/2019)',
        "type":"1026",
        "no":"Invoice",
        "duedate":"08/13/2019",
        "balance":"$314.28",
        "total":"$78.20",
        "status":"open"
    },
      {
        "checkbox":'09',
        "sno":'08',
        "date":'(19/02/2019)',
        "type":"1027",
        "no":"Invoice",
        "duedate":"09/13/2019",
        "balance":"$314.28",
        "total":"$78.20",
        "status":"open"
      },
        {
          "checkbox":'10',
          "sno":'09',
          "date":'(20/02/2019)',
          "type":"1028",
          "no":"Invoice",
          "duedate":"10/13/2019",
          "balance":"$314.28",
          "total":"$78.20",
          "status":"open"
        },
          
        {
            "checkbox":'11',
            "sno":'10',
            "date":'(21/02/2019)',
            "type":"1029",
            "no":"Invoice",
            "duedate":"11/13/2019",
            "balance":"$314.28",
            "total":"$78.20",
            "status":"open"
          },

]

  // console.log(this.collection)
  
}

// Sorting
setOrder(value: string) {
  console.log(value)
  if (this.order === value) {
    this.reverse = !this.reverse;
  }

  this.order = value;
}
// Sorting


// Scrollbar
public onScrollEvent(event: any): void {

}
// Scrollbar

}
